# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import numpy as np
import collections.abc
from enum import Enum
from pathlib import PurePath

def rescale_array(arr, minv=0.0, maxv=1.0, dtype=np.float32):
    """
    Rescale the values of numpy array `arr` to be from `minv` to `maxv`.
    """
    if dtype is not None:
        arr = arr.astype(dtype)

    mina = np.min(arr)
    maxa = np.max(arr)

    if mina == maxa:
        return arr * minv

    norm = (arr - mina) / (maxa - mina)
    return (norm * (maxv - minv)) + minv

def ensure_tuple(vals):
    """Returns a tuple of `vals`."""
    if not issequenceiterable(vals):
        vals = (vals,)

    return tuple(vals)

def issequenceiterable(obj):
    """Determine if the object is an iterable sequence and is not a string."""
    return isinstance(obj, collections.abc.Iterable) and not isinstance(obj, str)

def is_supported_format(filename, suffixes):
    """
    Verify whether the specified file or files format match supported suffixes.
    If supported suffixes is None, skip the verification and return True.
    Args:
        filename (Union[Sequence[str], str]): file name or a list of file names to read.
            if a list of files, verify all the suffixes.
        suffixes (Sequence[str]): all the supported image suffixes of current reader, must be a list of lower case suffixes.
    """
    filenames = ensure_tuple(filename)
    for name in filenames:
        tokens = PurePath(name).suffixes
        if len(tokens) == 0 or all("." + s.lower() not in "".join(tokens) for s in suffixes):
            return False

    return True

class PadMethod(str, Enum):
    SYMMETRIC = "symmetric"
    END = "end"

class PadMode(str, Enum):
    CONSTANT = "constant"
    EDGE = "edge"
    LINEAR_RAMP = "linear_ramp"
    MAXIMUM = "maximum"
    MEAN = "mean"
    MEDIAN = "median"
    MINIMUM = "minimum"
    REFLECT = "reflect"
    SYMMETRIC = "symmetric"
    WRAP = "wrap"
    EMPTY = "empty"

class InterpolateModePyTorch(Enum):
    NEAREST = "nearest"
    LINEAR = "linear"
    BILINEAR = "bilinear"
    BICUBIC = "bicubic"
    TRILINEAR = "trilinear"
    AREA = "area"

class InterpolateMode(Enum):
    NEAREST = 0
    BILINEAR = 1
    BIQUADRATIC = 2
    BICUBIC = 3
    BIQUARTIC = 4
    BIQUINTIC = 5
