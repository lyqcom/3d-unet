# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import numpy as np
from abc import abstractmethod

from suwen.transforms.vision import py_transforms as py_trans
from suwen.transforms.vision import py_transforms_util as util
from suwen.transforms.vision.validators import fall_back_tuple

class MapTransform:
    """
    A basic class with an assumption that the ``data`` input of 
    ``self.__call__`` is an array.

    The ``index`` parameter will be used to get and set the actual data
    columns to transform.  That is, the callable of this transform should
    follow the pattern:

        .. code-block:: python

            def __call__(self, *data):
                for idx in self.index:
                    data[idx] = self.converter(data[idx])
                return data
                
    Raises:
        ValueError: When ``index`` is an empty iterable.
        TypeError: When ``index`` type is not in ``Union[List[int], Tuple[int]]``.

    """

    def __init__(self, index):
        self.index = tuple(index)
        if not self.index:
            raise ValueError("keys must be non empty.")
        for idx in self.index:
            if not isinstance(idx, int):
                raise TypeError(f"indexes must be one of int but is {type(idx).__name__}.")

    @abstractmethod
    def __call__(self, data):
        """
        ``data`` often comes from an iteration over an iterable.

        To simplify the input validations, this method assumes:

        - ``data`` is a Python array
        - ``data[idx]`` is a Numpy ndarray, PyTorch Tensor or string, where ``idx`` is an int
         representing the index of the input column.
         
        - the channel dimension is not omitted even if number of channels is one

        Raises:
            NotImplementedError: When the subclass does not override this method.

        returns:
            An updated array version of ``data`` by applying the transform.

        """
        raise NotImplementedError(f"Subclass {self.__class__.__name__} must implement this method.")

class ToNumpy(MapTransform):
    """
    Array implementation, transfer the input data into numpy array.
    
    Args:
        index ([int, ], optional): index of columns to apply transforms.
        output_type (NumPy datatype, optional): The datatype of the NumPy output, e.g. numpy.float32.

    Examples:
        >>> transforms = [py_trans_array.ToNumpy(index = [0, 1], output_type = np.float32)]
        >>> dataset = dataset.map(operations=transforms, input_columns=["image", "mask"])
    """

    def __init__(self, index=[0], output_type=np.float32):
        super().__init__(index)
        self.converter = py_trans.ToNumpy(output_type = output_type)

    def __call__(self, *data):
        """
        Apply the transform to correponding columns of `data`.
        """
        d = list(data)
        if max(self.index) >= len(data):
            raise ValueError("index {} excced the number of column {}.".format(max(self.index), len(data)))
        for idx in self.index:
            d[idx] = self.converter(d[idx])
        return tuple(d)

class AddChannel(MapTransform):
    """
    Array implementation, adds a 1-length channel dimension to the 1st dimension of input images. 
    
    Args:
        index ([int, ], optional): index of columns to apply transforms.

    Examples:
        >>> transforms = [py_trans_array.AddChannel(index=[0, 1])]
        >>> dataset = dataset.map(operations=transforms, input_columns=["image1", "image2"])
    """

    def __init__(self, index=[0]):
        super().__init__(index)
        self.converter = py_trans.AddChannel()

    def __call__(self, *data):
        """
        Apply the transform to correponding columns of `data`.
        """
        d = list(data)
        if max(self.index) >= len(data):
            raise ValueError("index {} excced the number of column {}.".format(max(self.index), len(data)))
        for idx in self.index:
            d[idx] = self.converter(d[idx])
        return tuple(d)

class AsChannelFirst(MapTransform):
    """
    Array implementation, change the channel dimension of the image to the first dimension.

    Args:
        index ([int, ], optional): index of columns to apply transforms.
        channel_dim (int, optional): which dimension of input image is the channel, default is the last dimension.
        
    Examples:
        >>> transforms = [py_trans_array.AsChannelFirst(index=[0])]
        >>> dataset = dataset.map(operations=transforms, input_columns=["image", "mask"])
    """

    def __init__(self, index=[0]):
        super().__init__(index)
        self.converter = py_trans.AsChannelFirst()

    def __call__(self, *data):
        """
        Apply the transform to correponding columns of `data`.
        """
        d = list(data)
        if max(self.index) >= len(data):
            raise ValueError("index {} excced the number of column {}.".format(max(self.index), len(data)))
        for idx in self.index:
            d[idx] = self.converter(d[idx])
        return tuple(d)

class AsChannelLast(MapTransform):
    """
    Array implementation, change the channel dimension of the image to the last dimension.

    Args:
        index ([int, ], optional): index of columns to apply transforms.
        channel_dim (int, optional): which dimension of input image is the channel, default is the first dimension.
        
    Examples:
        >>> transforms = [py_trans_array.AsChannelLast(index=[0])]
        >>> dataset = dataset.map(operations=transforms, input_columns=["image", "mask"])
    """

    def __init__(self, index=[0]):
        super().__init__(index)
        self.converter = py_trans.AsChannelLast()

    def __call__(self, *data):
        """
        Apply the transform to correponding columns of `data`.
        """
        d = list(data)
        if max(self.index) >= len(data):
            raise ValueError("index {} excced the number of column {}.".format(max(self.index), len(data)))
        for idx in self.index:
            d[idx] = self.converter(d[idx])
        return tuple(d)

class RandSpatialCrop(py_trans.RandomizableTransform, MapTransform):
    """
    Array implementation, crop image with random size or specific size ROI. It can crop at a random position as
    center or at the image center. 
    
    Args:
        index ([int, ], optional): index of columns to apply transforms.
        roi_size (Union[Sequence[int], np.ndarray], optional): if `random_size` is True, it specifies the minimum crop region.
            if `random_size` is False, it specifies the expected ROI size to crop. e.g. [224, 224, 128]
            If its components have non-positive values, the corresponding size of input image will be used.
        random_center (bool, optional): crop at random position as center or the image center.
        random_size (bool, optional): crop with random size or specific size ROI.
            The actual size is sampled from `randint(roi_size, img_size)`.
            
    Examples:
        >>> transforms = [py_trans_array.RandSpatialCrop(index=[0, 1], roi_size = 224)]
        >>> dataset = dataset.map(operations=transforms, input_columns=["image", "mask"])
    """

    def __init__(self, index=[0], roi_size=None, random_center=True, random_size=False):
        py_trans.RandomizableTransform.__init__(self)
        MapTransform.__init__(self, index)
        self.roi_size = roi_size
        self.random_center = random_center
        self.random_size = random_size
        self._slices = None
        self._size = None

    def randomize(self, img_size):
        self._size = fall_back_tuple(self.roi_size, img_size)
        if self.random_size:
            self._size = [self.R.randint(low = self._size[i], high = img_size[i] + 1) for i in range(len(img_size))]
        if self.random_center:
            valid_size = util.get_valid_patch_size(img_size, self._size)
            self._slices = (slice(None),) + util.get_random_patch(img_size, valid_size, self.R)

    def __call__(self, *data):
        """
        Apply the transform to correponding columns of `data`.
        """
        d = list(data)
        if max(self.index) >= len(data):
            raise ValueError("index {} excced the number of column {}.".format(max(self.index), len(data)))

        self.randomize(d[self.index[0]].shape[1:])
        if self._size is None:
            raise AssertionError
        for idx in self.index:
            if self.random_center:
                d[idx] = d[idx][self._slices]
            else:
                cropper = py_trans.CenterSpatialCrop(self._size)
                d[idx] = cropper(d[idx])

        return tuple(d)

class ToOneHot(MapTransform):
    """
    Array implementation, perform one-hot transform to data.
    
    Args:
        index ([int, ], optional): index of columns to apply transforms.
        num_classes (int): number of classes
        label_map (List[int, ], optional): label map for uncontinuous labels
        
    Examples:
        >>> transforms = [py_trans_array.ToOneHot(index=[1], num_classes=2)]
        >>> dataset = dataset.map(operations=transforms, input_columns=["image", "mask"])
    """

    def __init__(self, index=[0], num_classes=None, label_map=None):
        super().__init__(index)
        self.converter = py_trans.ToOneHot(num_classes = num_classes, label_map = label_map)

    def __call__(self, *data):
        """
        Apply the transform to correponding columns of `data`.
        """
        d = list(data)
        if max(self.index) >= len(data):
            raise ValueError("index {} excced the number of column {}.".format(max(self.index), len(data)))
        for idx in self.index:
            d[idx] = self.converter(d[idx])
        return tuple(d)
