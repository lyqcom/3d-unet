# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import numpy as np
import nibabel as nib
from PIL import Image
from typing import Sequence, Union

from suwen.transforms.vision import py_transforms_util as util
from suwen.transforms.vision.validators import check_spatial_pad, fall_back_tuple
from suwen.transforms.vision.utils import PadMethod, PadMode, ensure_tuple, is_supported_format, rescale_array

MAX_SEED = np.iinfo(np.uint32).max + 1

class Randomizable:
    """
    An interface for handling random state locally, currently based on a class variable `R`,
    which is an instance of `np.random.RandomState`.
    """

    R = np.random.RandomState()

    def set_random_state(self, seed=None, state=None):
        """
        Set the random state locally, to control the randomness, the derived
        classes should use :py:attr:`self.R` instead of `np.random` to introduce random
        factors.
        
        Args:
            seed (int, optional): set the random state with an integer seed.
            state (np.random.RandomState, optional): set the random state with a `np.random.RandomState` object.
            
        Raises:
            TypeError: When ``state`` is not an ``Optional[np.random.RandomState]``.
            
        Returns:
            a Randomizable instance.
        """

        if seed is not None:
            _seed = id(seed) if not isinstance(seed, (int, np.integer)) else seed
            _seed = _seed % MAX_SEED
            self.R = np.random.RandomState(_seed)
            return self

        if state is not None:
            if not isinstance(state, np.random.RandomState):
                raise TypeError(f"state must be None or a np.random.RandomState but is {type(state).__name__}.")
            self.R = state
            return self

        self.R = np.random.RandomState()
        return self

    def randomize(self, data):
        """
        Within this method, :py:attr:`self.R` should be used, instead of `np.random`, to introduce random factors.
        all :py:attr:`self.R` calls happen here so that we have a better chance to
        identify errors of sync the random state.
        This method can generate the random factors based on properties of the input data.
        
        Raises:
            NotImplementedError: When the subclass does not override this method.
        """

        raise NotImplementedError(f"Subclass {self.__class__.__name__} must implement this method.")

class RandomizableTransform(Randomizable):
    """
    An interface for handling random state locally, currently based on a class variable `R`,
    which is an instance of `np.random.RandomState`.
    This is mainly for randomized data augmentation transforms. For example::
        class RandShiftIntensity(RandomizableTransform):
            def randomize():
                self._offset = self.R.uniform(low=0, high=100)
            def __call__(self, img):
                self.randomize()
                return img + self._offset
        transform = RandShiftIntensity()
        transform.set_random_state(seed=0)
    """

    def __init__(self, prob=1.0, do_transform=True):
        self._do_transform = do_transform
        self.prob = min(max(prob, 0.0), 1.0)

    def randomize(self, data):
        """
        Within this method, :py:attr:`self.R` should be used, instead of `np.random`, to introduce random factors.
        all :py:attr:`self.R` calls happen here so that we have a better chance to
        identify errors of sync the random state.
        This method can generate the random factors based on properties of the input data.
        """

        self._do_transform = self.R.rand() < self.prob

class ToNumpy:
    """
    Transfer the input data into numpy array.

    Args:
        output_type (NumPy datatype, optional): The datatype of the NumPy output, e.g. numpy.float32.

    Examples:
        >>> transforms = [py_trans.ToNumpy(np.float32)]
        >>> dataset = dataset.map(operations=transforms, input_columns="image")
    """

    def __init__(self, output_type=np.float32):
        self.output_type = output_type
        self.random = False
        self.converter = util.to_numpy

    def __call__(self, img):
        """
        Call method.

        Args:
            img (PIL image or np.array): image to be converted to numpy.ndarray.

        Returns:
            img (numpy.ndarray), Converted image.
        """
        return self.converter(img, self.output_type)

class AddChannel:
    """
    Adds a 1-length channel dimension to the 1st dimension of input image.

    Examples:
        >>> transforms = [py_trans.AddChannel()]
        >>> dataset = dataset.map(operations=transforms, input_columns="image")
    """

    def __init__(self):
        self.converter = util.add_channel

    def __call__(self, img):
        return self.converter(img)

class AsChannelFirst:
    """
    Change the channel dimension of the image to the first dimension.

    Args:
        channel_dim (int, optional): which dimension of input image is the channel, default is the last dimension.
    """

    def __init__(self, channel_dim=-1):
        if not (isinstance(channel_dim, int) and channel_dim >= -1):
            raise AssertionError("invalid channel dimension.")
        self.channel_dim = channel_dim
        self.converter = np.moveaxis

    def __call__(self, img):
        """
        Apply the transform to `img`.
        """
        return self.converter(img, self.channel_dim, 0)

class AsChannelLast:
    """
    Change the channel dimension of the image to the last dimension.

    Args:
        channel_dim (int, optional): which dimension of input image is the channel, default is the first dimension.
    """

    def __init__(self, channel_dim=0):
        if not (isinstance(channel_dim, int) and channel_dim >= -1):
            raise AssertionError("invalid channel dimension.")
        self.channel_dim = channel_dim
        self.converter = np.moveaxis

    def __call__(self, img):
        """
        Apply the transform to `img`.
        """
        return self.converter(img, self.channel_dim, -1)

class SpatialPad:
    """
    Performs padding operation on the input data, where input can be n-dimension array.

    Args:
        spatial_size (Union[int, sequence]): the spatial size of output data after padding.
            If its components have non-positive values, the corresponding size of input image will be used (no padding).
        method (PadMethod, optional): Image padding method (default=PadMethod.SYMMETRIC), it can be value of
            [PadMethod.SYMMETRIC, PadMethod.END], above PadMethod.SYMMETRIC means pad on each side of image, and
            PadMethod.END means on the end side.
        mode (PadMode, optional): Image padding mode (default=PadMode.CONSTANT). It can be any of [PadMode.CONSTANT,
            PadMode.EDGE, PadMode.LINEAR_RAMP, PadMode.MAXIMUM, PadMode.MEAN, PadMode.MEDIAN, PadMode.MINIMUM,
             PadMode.REFLECT, PadMode.SYMMETRIC, PadMode.WRAP, PadMode.EMPTY].
             See also: https://numpy.org/doc/1.18/reference/generated/numpy.pad.html

    Examples:
        >>> transforms = [py_trans.SpatialPad([3, 768, 1024, 128])]
        >>> dataset = dataset.map(operations=transforms, input_columns="image")
    """

    @check_spatial_pad
    def __init__(self, spatial_size, method=PadMethod.SYMMETRIC, mode=PadMode.CONSTANT):
        self.spatial_size = spatial_size
        self.method = PadMethod(method)
        self.mode = PadMode(mode)
        self.converter = util.spatial_pad

    def __call__(self, img, mode=None):
        """
        Call method.

        Args:
            img (numpy.ndarray): data to be applied spatial pad, assuming the channel dim is the first dimension of
             input data. And padding operation doesn't apply to the channel dim.
            mode (PadMode, optional): Image padding mode (default=PadMode.CONSTANT). It can be any of
            [PadMode.CONSTANT, PadMode.EDGE, PadMode.LINEAR_RAMP, PadMode.MAXIMUM, PadMode.MEAN, PadMode.MEDIAN,
             PadMode.MINIMUM, PadMode.REFLECT, PadMode.SYMMETRIC, PadMode.WRAP, PadMode.EMPTY].
                See also: https://numpy.org/doc/1.18/reference/generated/numpy.pad.html

        Return:
            img (numpy.ndarray), spatial padded image.

        """
        return self.converter(img, self.spatial_size, self.method,
                              mode = self.mode.value if mode is None else PadMode(mode).value)

class ToOneHot:
    """
    Perform one-hot transform on the segmentation mask.
    
    Args:
        num_classes (int): number of classes
        label_map (List[int, ], optional): label map for uncontinuous labels
        
    Examples:
        >>> transforms = [py_trans.ToOneHot(num_classes=2)]
        >>> dataset = dataset.map(operations=transforms, input_columns="mask")
    """

    def __init__(self, num_classes=None, label_map=None):
        if num_classes and label_map:
            if not len(label_map) == num_classes:
                raise ValueError(
                    "length of label_map should be the same with num_classes={}. Got {}.".format(num_classes,
                                                                                                 len(label_map)))
        self.num_classes = num_classes if num_classes else len(label_map) if label_map else 1
        self.label_map = label_map if label_map else list(range(num_classes))
        self.converter = util.to_one_hot

    def __call__(self, mask):
        """
        Apply the transform to `mask`.
        """
        return self.converter(mask, self.num_classes, self.label_map)

class SpatialCrop:
    """
    General purpose cropper to produce sub-volume region of interest (ROI).
    It can support to crop ND spatial (channel-first) data.
    Either a spatial center and size must be provided, or alternatively,
    if center and size are not provided, the start and end coordinates of the ROI must be provided.
    
    Args:
        roi_center (Union[Sequence[int], np.ndarray], optional): voxel coordinates for center of the crop ROI.
        roi_size (Union[Sequence[int], np.ndarray], optional): size of the crop ROI.
        roi_start (Union[Sequence[int], np.ndarray], optional): voxel coordinates for start of the crop ROI.
        roi_end (Union[Sequence[int], np.ndarray], optional): voxel coordinates for end of the crop ROI.
    """

    def __init__(
            self,
            roi_center=None,
            roi_size=None,
            roi_start=None,
            roi_end=None):

        if roi_center is not None and roi_size is not None:
            roi_center = np.asarray(roi_center, dtype = np.int16)
            roi_size = np.asarray(roi_size, dtype = np.int16)
            self.roi_start = np.maximum(roi_center - np.floor_divide(roi_size, 2), 0)
            self.roi_end = np.maximum(self.roi_start + roi_size, self.roi_start)
        else:
            if roi_start is None or roi_end is None:
                raise ValueError("Please specify either roi_center, roi_size or roi_start, roi_end.")
            self.roi_start = np.maximum(np.asarray(roi_start, dtype = np.int16), 0)
            self.roi_end = np.maximum(np.asarray(roi_end, dtype = np.int16), self.roi_start)

    def __call__(self, img):
        """
        Apply the transform to `img`, assuming `img` is channel-first and
        slicing doesn't apply to the channel dim.
        """
        sd = min(len(self.roi_start), len(self.roi_end), len(img.shape[1:]))
        slices = [slice(None)] + [slice(s, e) for s, e in zip(self.roi_start[:sd], self.roi_end[:sd])]
        return np.asarray(img[tuple(slices)])

class CenterSpatialCrop:
    """
    Crop at the center of image with specified ROI size.
    
    Args:
        roi_size (Union[Sequence[int], int]): the spatial size of the crop region e.g. [224,224,128]
            If its components have non-positive values, the corresponding size of input image will be used.
    """

    def __init__(self, roi_size):
        self.roi_size = roi_size

    def __call__(self, img):
        """
        Apply the transform to `img`, assuming `img` is channel-first and
        slicing doesn't apply to the channel dim.
        """
        center = [i // 2 for i in img.shape[1:]]
        cropper = SpatialCrop(roi_center = center, roi_size = self.roi_size)
        return cropper(img)

class RandSpatialCrop(RandomizableTransform):
    """
    Crop image with random size or specific size ROI. It can crop at a random position as center
    or at the image center. And allows to set the minimum size to limit the randomly generated ROI.
    Args:
        roi_size (Union[Sequence[int], int]): if `random_size` is True, it specifies the minimum crop region.
            if `random_size` is False, it specifies the expected ROI size to crop. e.g. [224, 224, 128]
            If its components have non-positive values, the corresponding size of input image will be used.
        random_center (bool, optional): crop at random position as center or the image center.
        random_size (bool, optional): crop with random size or specific size ROI.
            The actual size is sampled from `randint(roi_size, img_size)`.
    """

    def __init__(self, roi_size, random_center=True, random_size=False):
        self.roi_size = roi_size
        self.random_center = random_center
        self.random_size = random_size
        self._size = None
        self._slices = None

    def randomize(self, img_size):
        self._size = fall_back_tuple(self.roi_size, img_size)
        if self.random_size:
            self._size = tuple(
                (self.R.randint(low = self._size[i], high = img_size[i] + 1) for i in range(len(img_size))))
        if self.random_center:
            valid_size = util.get_valid_patch_size(img_size, self._size)
            self._slices = (slice(None),) + util.get_random_patch(img_size, valid_size, self.R)

    def __call__(self, img):
        """
        Apply the transform to `img`, assuming `img` is channel-first and
        slicing doesn't apply to the channel dim.
        """
        self.randomize(img.shape[1:])
        if self._size is None:
            raise AssertionError
        if self.random_center:
            return img[self._slices]
        cropper = CenterSpatialCrop(self._size)
        return cropper(img)

class NibabelReader:
    """
    Load NIfTI format images based on Nibabel library.
    Args:
        as_closest_canonical (bool, optional): if True, load the image as closest to canonical axis format.
        dtype (numpy datatype, optional): datatype
        kwargs (optional): additional args for `nibabel.load` API. more details about available args:
            https://github.com/nipy/nibabel/blob/master/nibabel/loadsave.py
    """

    def __init__(self, as_closest_canonical=False, dtype=np.float32, **kwargs):
        self.as_closest_canonical = as_closest_canonical
        self.dtype = dtype
        self.kwargs = kwargs

    def verify_suffix(self, filename):
        """
        Verify whether the specified file or files format is supported by Nibabel reader.
        Args:
            filename: (Union[Sequence[str], str]): file name or a list of file names to read.
                if a list of files, verify all the suffixes.
        """
        suffixes = ["nii", "nii.gz"]
        return is_supported_format(filename, suffixes)

    def read_as_numpy(self, data, **kwargs):
        """
        Read image data from specified file or files as numpy array
        Args:
            data (Union[Sequence[str], str]): file name or a list of file names to read.
            kwargs (optional): additional args for `nibabel.load` API, will override `self.kwargs` for existing keys.
                More details about available args:
                https://github.com/nipy/nibabel/blob/master/nibabel/loadsave.py
        """
        img_ = self.read(data, **kwargs)
        img_ = self._get_array_data(img_)

        return img_

    def read(self, data, **kwargs):
        """
        Read image data from specified file or files.
        Note that the returned object is Nibabel image object or list of Nibabel image objects.
        Args:
            data (Union[Sequence[str], str]): file name or a list of file names to read.
            kwargs (optional): additional args for `nibabel.load` API, will override `self.kwargs` for existing keys.
                More details about available args:
                https://github.com/nipy/nibabel/blob/master/nibabel/loadsave.py
        """
        img_ = []

        filenames = ensure_tuple(data)
        kwargs_ = self.kwargs.copy()
        kwargs_.update(kwargs)
        for name in filenames:
            img = nib.load(name, **kwargs_)
            img_.append(img)
        return img_ if len(filenames) > 1 else img_[0]

    def _get_meta_dict(self, img):
        """
        Get the all the meta data of the image and convert to dict type.
        Args:
            img: a Nibabel image object loaded from a image file.
        """
        return dict(img.header)

    def _get_affine(self, img):
        """
        Get the affine matrix of the image, it can be used to correct
        spacing, orientation or execute spatial transforms.
        Args:
            img: a Nibabel image object loaded from a image file.
        """
        return np.array(img.affine, copy = True)

    def _get_spatial_shape(self, img):
        """
        Get the spatial shape of image data, it doesn't contain the channel dim.
        Args:
            img: a Nibabel image object loaded from a image file.
        """
        ndim = img.header["dim"][0]
        spatial_rank = min(ndim, 3)
        return np.asarray(img.header["dim"][1: spatial_rank + 1])

    def _get_array_data(self, img):
        """
        Get the raw array data of the image, converted to Numpy array.
        Args:
            img: a Nibabel image object loaded from a image file.
        """
        _array = np.array(img.get_fdata(dtype = self.dtype))
        img.uncache()
        return _array

def _copy_compatible_dict(from_dict, to_dict):
    if not isinstance(to_dict, dict):
        raise ValueError(f"to_dict must be a Dict, got {type(to_dict)}.")
    if not to_dict:
        for key in from_dict:
            datum = from_dict[key]
            if isinstance(datum, np.ndarray):
                continue
            to_dict[key] = datum
    else:
        affine_key, shape_key = "affine", "spatial_shape"
        if affine_key in from_dict and not np.allclose(from_dict[affine_key], to_dict[affine_key]):
            raise RuntimeError(
                "affine matrix of all images should be the same for channel-wise concatenation. "
                f"Got {from_dict[affine_key]} and {to_dict[affine_key]}."
            )
        if shape_key in from_dict and not np.allclose(from_dict[shape_key], to_dict[shape_key]):
            raise RuntimeError(
                "spatial_shape of all images should be the same for channel-wise concatenation. "
                f"Got {from_dict[shape_key]} and {to_dict[shape_key]}."
            )

def _stack_images(image_list, meta_dict):
    if len(image_list) > 1:
        if meta_dict.get("original_channel_dim", None) not in ("no_channel", None):
            raise RuntimeError("can not read a list of images which already have channel dimension.")
        meta_dict["original_channel_dim"] = 0
        img_array = np.stack(image_list, axis=0)
    else:
        img_array = image_list[0]
    return img_array

class PILReader:
    """
    Load common 2D image format (supports PNG, JPG, BMP) file or files from provided path.
    Args:
        converter ([Callable], optional): additional function to convert the image data after `read()`.
            for example, use `converter=lambda image: image.convert("LA")` to convert image format.
        kwargs (optional): additional args for `Image.open` API in `read()`, mode details about available args:
            https://pillow.readthedocs.io/en/stable/reference/Image.html#PIL.Image.open
    """

    def __init__(self, converter=None, **kwargs):
        super().__init__()
        self.converter = converter
        self.kwargs = kwargs

    def verify_suffix(self, filename):
        """
        Verify whether the specified file or files format is supported by PIL reader.
        Args:
            filename (Union[Sequence[str], str]): file name or a list of file names to read.
                if a list of files, verify all the suffixes.
        """
        suffixes = ["png", "jpg", "jpeg", "bmp"]
        return is_supported_format(filename, suffixes)

    def read(self, data, **kwargs):
        """
        Read image data from specified file or files.
        Note that the returned object is PIL image or list of PIL image.
        Args:
            data (Union[Sequence[str], str, np.ndarray]): file name or a list of file names to read.
            kwargs (optional): additional args for `Image.open` API in `read()`, will override `self.kwargs` for existing keys.
                Mode details about available args:
                https://pillow.readthedocs.io/en/stable/reference/Image.html#PIL.Image.open
        """
        img_ = []

        filenames = ensure_tuple(data)
        kwargs_ = self.kwargs.copy()
        kwargs_.update(kwargs)
        for name in filenames:
            img = Image.open(name, **kwargs_)
            if callable(self.converter):
                img = self.converter(img)
            img_.append(img)

        return img_ if len(filenames) > 1 else img_[0]

    def get_data(self, img):
        """
        Extract data array and meta data from loaded data and return them.
        This function returns 2 objects, first is numpy array of image data, second is dict of meta data.
        It constructs `spatial_shape` and stores in meta dict.
        If loading a list of files, stack them together and add a new dimension as first dimension,
        and use the meta data of the first image to represent the stacked result.

        Args:
            img: a PIL Image object loaded from a file or a list of PIL Image objects.

        """
        img_array = []
        compatible_meta = {}

        for i in ensure_tuple(img):
            header = self._get_meta_dict(i)
            header["spatial_shape"] = self._get_spatial_shape(i)
            data = np.asarray(i)
            img_array.append(data)
            header["original_channel_dim"] = "no_channel" if len(data.shape) == len(header["spatial_shape"]) else -1
            _copy_compatible_dict(header, compatible_meta)

        return _stack_images(img_array, compatible_meta), compatible_meta

    def _get_meta_dict(self, img):
        """
        Get the all the meta data of the image and convert to dict type.
        Args:
            img: a PIL Image object loaded from a image file.
        """
        return {
            "format": img.format,
            "mode": img.mode,
            "width": img.width,
            "height": img.height,
        }

    def _get_spatial_shape(self, img):
        """
        Get the spatial shape of image data, it doesn't contain the channel dim.
        Args:
            img: a PIL Image object loaded from a image file.
        """
        return np.asarray((img.width, img.height))

class LoadImage:
    """
    Load image file or files from provided path based on reader.
    Automatically choose readers based on the supported suffixes and in below order:
    - User specified reader at runtime when call this loader.
    - Registered readers from the latest to the first in list.
    - Default readers: (nii, nii.gz -> NibabelReader), (png, jpg, bmp -> PILReader),
    (npz, npy -> NumpyReader), (others -> ITKReader).

    """

    def __init__(self, reader=PILReader(), image_only=False, dtype=np.float32):
        """
        Args:
            reader: register reader to load image file and meta data, if None, still can register readers
                at runtime or use the default readers. If a string of reader name provided, will construct
                a reader object with the `*args` and `**kwargs` parameters, supported reader name: "NibabelReader",
                "PILReader", "ITKReader", "NumpyReader"
            image_only: if True return only the image volume, otherwise return image data array and header dict.
            dtype: if not None convert the loaded image to this data type.

        Note:
            The transform returns image data array if `image_only` is True,
            or a tuple of two elements containing the data array, and the meta data in a dict format otherwise.

        """
        self.readers = PILReader()
        if reader is not None:
            if isinstance(reader, str):
                supported_readers = {
                    "pilreader": PILReader,
                }
                reader = reader.lower()
                if reader not in supported_readers:
                    raise ValueError(f"unsupported reader type: {reader}, available options: {supported_readers}.")
        else:
            raise RuntimeError(f"can not find suitable reader for this file: filename.")
        self.image_only = image_only
        self.dtype = dtype

    def operation(self, filename):
        """
        Args:
            filename: path file or file-like object or a list of files.
                will save the filename to meta_data with key `filename_or_obj`.
                if provided a list of files, use the filename of first file.
            reader: runtime reader to load image file and meta data.

        """
        img = self.readers.read(filename)
        img_array, meta_data = self.readers.get_data(img)
        img_array = img_array.astype(self.dtype)

        return img_array

    def __call__(self, image, label):
        image = str(image, encoding = "utf-8")
        label = str(label, encoding = "utf-8")
        return self.operation(image), self.operation(label)

class AddChannel:
    """
    Adds a 1-length channel dimension to the input image.

    Most of the image transformations in ``monai.transforms``
    assumes the input image is in the channel-first format, which has the shape
    (num_channels, spatial_dim_1[, spatial_dim_2, ...]).

    This transform could be used, for example, to convert a (spatial_dim_1[, spatial_dim_2, ...])
    spatial image into the channel-first format so that the
    multidimensional image array can be correctly interpreted by the other
    transforms.
    """

    def operation(self, img):
        """
        Apply the transform to `img`.
        """
        return img[None]

    def __call__(self, img, label):
        return self.operation(img), self.operation(label)

class ScaleIntensity:
    """
    Scale the intensity of input image to the given value range (minv, maxv).
    If `minv` and `maxv` not provided, use `factor` to scale image by ``v = v * (1 + factor)``.
    """

    def __init__(self, minv=0.0, maxv=1.0, factor=None):
        """
        Args:
            minv: minimum value of output data.
            maxv: maximum value of output data.
            factor: factor scale by ``v = v * (1 + factor)``.
        """
        self.minv = minv
        self.maxv = maxv
        self.factor = factor

    def operation(self, img):
        """
        Apply the transform to `img`.

        Raises:
            ValueError: When ``self.minv=None`` or ``self.maxv=None`` and ``self.factor=None``. Incompatible values.

        """
        if self.minv is not None and self.maxv is not None:
            return rescale_array(img, self.minv, self.maxv, img.dtype)
        if self.factor is not None:
            return (img * (1 + self.factor)).astype(img.dtype)
        raise ValueError("Incompatible values: minv=None or maxv=None and factor=None.")

    def __call__(self, img, label):
        return self.operation(img), label

class Rotate90:
    """
    Rotate an array by 90 degrees in the plane specified by `axes`.
    """

    def __init__(self, k=1, spatial_axes=(0, 1)):
        """
        Args:
            k: number of times to rotate by 90 degrees.
            spatial_axes: 2 int numbers, defines the plane to rotate with 2 spatial axes.
                Default: (0, 1), this is the first two axis in spatial dimensions.
        """
        self.k = k
        spatial_axes_ = ensure_tuple(spatial_axes)
        if len(spatial_axes_) != 2:
            raise ValueError("spatial_axes must be 2 int numbers to indicate the axes to rotate 90 degrees.")
        self.spatial_axes = spatial_axes_

    def __call__(self, img: np.ndarray) -> np.ndarray:
        """
        Args:
            img: channel first array, must have shape: (num_channels, H[, W, ..., ]),
        """
        rotated = []
        for channel in img:
            rotated.append(np.rot90(channel, self.k, self.spatial_axes))
        return np.stack(rotated).astype(img.dtype)

class RandRotate90:
    """
    Dictionary-based version :py:class:`monai.transforms.RandRotate90`.
    With probability `prob`, input arrays are rotated by 90 degrees
    in the plane specified by `spatial_axes`.
    """

    def __init__(self, prob=0.1, max_k=3, spatial_axes=(0, 1)):
        """
        Args:
            prob: probability of rotating.
                (Default 0.1, with 10% probability it returns a rotated array.)
            max_k: number of rotations will be sampled from `np.random.randint(max_k) + 1`.
                (Default 3)
            spatial_axes: 2 int numbers, defines the plane to rotate with 2 spatial axes.
                Default: (0, 1), this is the first two axis in spatial dimensions.
        """
        self.prob = min(max(prob, 0.0), 1.0)
        self.max_k = max_k
        self.spatial_axes = spatial_axes
        self._do_transform = False
        self._rand_k = 0
        self.set_random_state(MAX_SEED)

    def set_random_state(self, seed=None, state=None):
        """
        Set the random state locally, to control the randomness, the derived
        classes should use :py:attr:`self.R` instead of `np.random` to introduce random
        factors.

        Args:
            seed: set the random state with an integer seed.
            state: set the random state with a `np.random.RandomState` object.

        Raises:
            TypeError: When ``state`` is not an ``Optional[np.random.RandomState]``.

        Returns:
            a Randomizable instance.

        """
        if seed is not None:
            _seed = id(seed) if not isinstance(seed, (int, np.integer)) else seed
            _seed = _seed % MAX_SEED
            self.R = np.random.RandomState(_seed)
            return self

        if state is not None:
            if not isinstance(state, np.random.RandomState):
                raise TypeError(f"state must be None or a np.random.RandomState but is {type(state).__name__}.")
            self.R = state
            return self

        self.R = np.random.RandomState()
        return self

    def randomize(self, data=None):
        self._rand_k = self.R.randint(self.max_k) + 1
        self._do_transform = self.R.random() < self.prob

    def __call__(self, img, label):
        self.randomize()
        if not self._do_transform:
            return img, label
        rotator = Rotate90(self._rand_k, self.spatial_axes)

        return rotator(img), rotator(label)

class RandGaussianNoise:
    """
    Add Gaussian noise to image.

    Args:
        prob: Probability to add Gaussian noise.
        mean: Mean or “centre” of the distribution.
        std: Standard deviation (spread) of distribution.
    """

    def __init__(self, prob: float = 0.1, mean=0.0, std=0.1):
        self.prob = prob
        self.mean = mean
        self.std = std
        self._do_transform = False
        self._noise = None
        self.set_random_state(MAX_SEED)

    def set_random_state(self, seed=None, state=None):
        """
        Set the random state locally, to control the randomness, the derived
        classes should use :py:attr:`self.R` instead of `np.random` to introduce random
        factors.

        Args:
            seed: set the random state with an integer seed.
            state: set the random state with a `np.random.RandomState` object.

        Raises:
            TypeError: When ``state`` is not an ``Optional[np.random.RandomState]``.

        Returns:
            a Randomizable instance.

        """
        if seed is not None:
            _seed = id(seed) if not isinstance(seed, (int, np.integer)) else seed
            _seed = _seed % MAX_SEED
            self.R = np.random.RandomState(_seed)
            return self

        if state is not None:
            if not isinstance(state, np.random.RandomState):
                raise TypeError(f"state must be None or a np.random.RandomState but is {type(state).__name__}.")
            self.R = state
            return self

        self.R = np.random.RandomState()
        return self

    def randomize(self, im_shape):
        self._do_transform = self.R.random() < self.prob
        self._noise = self.R.normal(self.mean, self.R.uniform(0, self.std), size = im_shape)

    def __call__(self, img, label):
        """
        Apply the transform to `img`.
        """
        self.randomize(img.shape)
        if self._noise is None:
            raise AssertionError
        if not self._do_transform:
            return img, label
        return img + self._noise.astype(img.dtype), label + self._noise.astype(label.dtype)
