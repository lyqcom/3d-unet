# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

from mindspore.dataset.vision.c_transforms import AutoContrast, BoundingBoxAugment, CenterCrop, CutMixBatch, CutOut, \
    Decode, Equalize, HWC2CHW, Invert, MixUpBatch, Normalize, Pad, RandomAffine, RandomColor, RandomColorAdjust, \
    RandomCrop, RandomCropDecodeResize, RandomCropWithBBox, RandomHorizontalFlip, RandomHorizontalFlipWithBBox, \
    RandomPosterize, RandomResizedCrop, RandomResizedCropWithBBox, RandomResize, RandomResizeWithBBox, RandomRotation, \
    RandomSelectSubpolicy, RandomSharpness, RandomSolarize, RandomVerticalFlip, RandomVerticalFlipWithBBox, Rescale, \
    Resize, ResizeWithBBox, SoftDvppDecodeRandomCropResizeJpeg, SoftDvppDecodeResizeJpeg, UniformAugment, NormalizePad
from mindspore.dataset.vision.py_transforms import HsvToRgb, RgbToHsv, MixUp, LinearTransformation, Cutout, \
    RandomErasing, RandomPerspective, RandomGrayscale, Grayscale, TenCrop, FiveCrop, ToPIL, ToType, ToTensor

from suwen.transforms.vision import py_transforms_array
from suwen.transforms.vision.py_transforms import RandomizableTransform, ToNumpy, AddChannel, AsChannelFirst, \
    AsChannelLast, SpatialPad, ToOneHot, SpatialCrop, CenterSpatialCrop, RandSpatialCrop, NibabelReader, PILReader, \
    ScaleIntensity, RandRotate90, RandGaussianNoise, LoadImage

__all__ = [
    'py_transforms_array',
    'BoundingBoxAugment',
    'CutMixBatch',
    'CutOut',
    'MixUpBatch',
    'NormalizePad',
    'RandomCropDecodeResize',
    'RandomCropWithBBox',
    'RandomHorizontalFlipWithBBox',
    'RandomPosterize',
    'RandomResizedCropWithBBox',
    'RandomResize',
    'RandomResizeWithBBox',
    'RandomSelectSubpolicy',
    'RandomSolarize',
    'RandomVerticalFlipWithBBox',
    'Rescale',
    'ResizeWithBBox',
    'SoftDvppDecodeRandomCropResizeJpeg',
    'SoftDvppDecodeResizeJpeg',
    'NibabelReader',
    'PILReader',
    'ScaleIntensity',
    'LoadImage',
    'RandRotate90',
    'RandGaussianNoise',
    'UniformAugment',
    'Equalize',
    'Invert',
    'AutoContrast',
    'RandomSharpness',
    'RandomColor',
    'HsvToRgb',
    'RgbToHsv',
    'MixUp',
    'RandomAffine',
    'LinearTransformation',
    'Cutout',
    'RandomErasing',
    'RandomPerspective',
    'Pad',
    'RandomGrayscale',
    'Grayscale',
    'TenCrop',
    'FiveCrop',
    'RandomRotation',
    'RandomColorAdjust',
    'CenterCrop',
    'RandomResizedCrop',
    'Resize',
    'RandomVerticalFlip',
    'RandomHorizontalFlip',
    'RandomCrop',
    'Normalize',
    'Decode',
    'ToPIL',
    'HWC2CHW',
    'ToType',
    'ToTensor',
    'RandomizableTransform',
    'ToNumpy',
    'AddChannel',
    'AsChannelFirst',
    'AsChannelLast',
    'SpatialPad',
    'ToOneHot',
    'SpatialCrop',
    'CenterSpatialCrop',
    'RandSpatialCrop'
]
