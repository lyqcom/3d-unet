# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import numpy as np
from PIL import Image
from typing import Union

from suwen.transforms.vision.utils import PadMethod, PadMode
from suwen.transforms.vision.validators import ensure_tuple_size

def to_numpy(img, output_type):
    """
    Transfer the input data into numpy array.

    Args:
        output_type (NumPy datatype, optional): The datatype of the NumPy output, e.g. numpy.float32.

    Examples:
        >>> transforms = [py_trans.ToNumpy(np.float32)]
        >>> dataset = dataset.map(operations=transforms, input_columns="image")
    """
    if not (isinstance(img, Image.Image) or isinstance(img, np.ndarray)):
        raise TypeError("img should be PIL image or NumPy array. Got {}.".format(type(img)))

    return np.asarray(img, dtype = output_type)


def add_channel(img):
    """
    Adds a 1-length channel dimension to the input image.

    Args:
        img (numpy.ndarray): label to be applied add channel.

    Returns:
        img (numpy.ndarray), image after being add channel in the first dimension.
    """
    if not (isinstance(img, np.ndarray)):
        raise TypeError("img should be NumPy array. Got {}.".format(type(img)))

    return img[None]


def spatial_pad(img, spatial_size, method, mode):
    """
    Performs padding operation on the input data, where input can be n-dimension array.

    Args:
        img (numpy.ndarray): Image to be applied spatial pad.
        spatial_size (Union[int, sequence]): the spatial size of output data after padding.
            If its components have non-positive values, the corresponding size of input image will be used (no padding).
        method (PadMethod): Image padding method, default is Method.SYMMETRIC.
        mode (PadMode): Implemented numpy padding mode, default is PadMode.CONSTANT.

    Returns:
        img (numpy.ndarray), spatial padded image.
    """

    data_shape = img.shape[1:]
    required_size = []
    for size1, size2 in zip(spatial_size, data_shape):
        if size1 > 0:
            required_size.append(size1)
        else:
            required_size.append(size2)
    spatial_size = tuple(required_size)

    if method == PadMethod.SYMMETRIC:
        pad_width = []
        for i in range(len(spatial_size)):
            width = max(spatial_size[i] - data_shape[i], 0)
            pad_width.append((width // 2, width - (width // 2)))
        data_pad_width = pad_width
    else:
        data_pad_width = [(0, max(spatial_size[i] - data_shape[i], 0)) for i in range(len(spatial_size))]

    all_pad_width = [(0, 0)] + data_pad_width
    if np.asarray(all_pad_width).any():
        img = np.pad(img, all_pad_width, mode)
        return img

    return img


def to_one_hot(mask, num_classes, label_map=None):
    """
    Transfer segmentation mask/label in shape (spatial_dim1[, spatial_dim2]) to 
    one-hot mask/label in shape (num_classes, spatial_dim1[, spatial_dim2]).
    
    Args:
        mask (numpy.ndarray or PIL.Image): segmentation mask to apply one-hot transform
        num_classes (int): number of classes
        label_map (List[int, ], optional): label map for uncontinuous labels
        
    Returns:
        img (numpy.ndarray), one-hot mask.
    """

    mask = np.array(mask)
    if mask.ndim == 0:
        return one_hot_encoding(mask, num_classes)
    mask_dim = [num_classes] + list(mask.shape)
    one_hot_mask = np.zeros(mask_dim)

    if not label_map:
        label_map = list(range(num_classes))

    for i, label in enumerate(label_map):
        one_hot_mask[i, :] = (mask == label)
    return one_hot_mask


def get_valid_patch_size(image_size, patch_size):
    """
    Given an image of dimensions `image_size`, return a patch size tuple taking the dimension from `patch_size` if this is
    not 0/None. Otherwise, or if `patch_size` is shorter than `image_size`, the dimension from `image_size` is taken. This ensures
    the returned patch size is within the bounds of `image_size`. If `patch_size` is a single number this is interpreted as a
    patch of the same dimensionality of `image_size` with that size in each dimension.
    
    Args:
        image_size (sequence): shape of the image
        patch_size (Union[int, sequence]): shape of the patch
        
    Returns:
        (sequence), valid shape of the patch.
    """

    ndim = len(image_size)
    patch_size_ = ensure_tuple_size(patch_size, ndim)

    return tuple(min(ms, ps or ms) for ms, ps in zip(image_size, patch_size_))


def get_random_patch(dims, patch_size, rand_state=None):
    """
    Returns a tuple of slices to define a random patch in an array of shape `dims` with size `patch_size` or the as
    close to it as possible within the given dimension. It is expected that `patch_size` is a valid patch for a source
    of shape `dims` as returned by `get_valid_patch_size`.
    
    Args:
        dims (sequence): shape of source array
        patch_size (sequence): shape of patch size to generate
        rand_state : a random state object to generate random numbers from
        
    Returns:
        (tuple of slice): a tuple of slice objects defining the patch
    """

    rand_int = np.random.randint if rand_state is None else rand_state.randint
    min_corner = tuple(rand_int(0, ms - ps + 1) if ms > ps else 0 for ms, ps in zip(dims, patch_size))

    return tuple(slice(mc, mc + ps) for mc, ps in zip(min_corner, patch_size))


def one_hot_encoding(label, num_classes, epsilon=0):
    """
    Apply label smoothing transformation to the input label, and make label be more smoothing and continuous.

    Args:
        label (numpy.ndarray): label to be applied label smoothing.
        num_classes (int): Num class of object in dataset, value should over 0.
        epsilon (float): The adjustable Hyper parameter. Default is 0.0.

    Returns:
        img (numpy.ndarray), label after being one hot encoded and done label smoothed.
    """
    if (label > num_classes).any():
        raise ValueError('the num_classes is smaller than the category number.')

    num_elements = label.size
    one_hot_label = np.zeros((num_elements, num_classes), dtype = int)

    if isinstance(label, list) is False:
        label = [label]
    for index in range(num_elements):
        one_hot_label[index, label[index]] = 1

    return (1 - epsilon) * one_hot_label + epsilon / num_classes
