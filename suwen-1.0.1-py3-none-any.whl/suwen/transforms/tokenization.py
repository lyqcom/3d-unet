# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

from __future__ import absolute_import, division, print_function, unicode_literals

import os
import logging
import collections
import unicodedata
from io import open

logger = logging.getLogger(__name__)

VOCAB_NAME = 'vocab.txt'

def load_vocab(vocab_file):
    """
    Load a vocabulary file inro a dictionary.
    :param vocab_file: (str) Vocab file path.
    :return: (dic1at) vobal file info
    """
    vocab = collections.OrderedDict()
    index = 0
    with open(vocab_file, 'r', encoding = 'utf-8') as reader:
        while True:
            token = reader.readline()
            if not token:
                break
            token = token.strip()
            vocab[token] = index
            index += 1
    return vocab


def whitespace_tokenize(text):
    """
    Runs basic whitespace cleaning and splitting on a piece of text.
    :param text: (str) text
    :return: (list) tokens
    """
    text = text.strip()
    if not text:
        return []
    tokens = text.split()
    return tokens

class BertTokenizer(object):
    """
    Runs end-to-end tokenization: punctuation splitting + wordpiece.
    """

    def __init__(self, vocab_file, do_lower_case=True, max_len=None, do_basic_tokenize=True, basic_only=False,
                 never_split=('[UNK]', '[SEP]', '[PAD]', '[CLS]', '[MASK]')):
        """
        Constructs a BertTokenizer.
        :param vocab_file: (str) Path to a one-wordpiece-per-line vocabulary file.
        :param do_lower_case: (bool) Whether to lower case, Only has an effect when do_wordpiece_only=False.
        :param max_len: (int) An artificial maximum length to truncate tokenized sequences to Effective maximum length
        is always the minimum of this value (if specified) and the underlying BERT model's sequence length.
        :param do_basic_tokenize:
        :param basic_only:
        :param never_split: (list) List of tokens which will never be split during tokenization. Only has an effect
        when do_wordpiece_only=False.
        """
        if not os.path.isfile(vocab_file):
            raise ValueError("Can't find a vocabulary file at path '{}'.".format(vocab_file))
        self.vocab = load_vocab(vocab_file)
        self.ids_to_tokens = collections.OrderedDict([(ids, tok) for tok, ids in self.vocab.items()])
        self.do_basic_tokenize = do_basic_tokenize
        if do_basic_tokenize:
            self.basic_tokenizer = BasicTokenizer(do_lower_case = do_lower_case, never_split = never_split)
        self.wordpiece_tokenizer = WordpieceTokenizer(vocab = self.vocab)
        self.max_len = max_len if max_len is not None else int(1e12)
        self.basic_only = basic_only

    def tokenize(self, text):
        """
        Tokenizes a piece of text.
        :param text:
        :return:
        """
        split_tokens = []
        if self.do_basic_tokenize:
            for token in self.basic_tokenizer.tokenize(text):
                if self.basic_only:
                    split_tokens.append(token)
                else:
                    for sub_token in self.wordpiece_tokenizer.tokenize(token):
                        split_tokens.append(sub_token)
        else:
            split_tokens = self.wordpiece_tokenizer.tokenize(text)
        return split_tokens

    def convert_tokens_to_ids(self, tokens):
        """
        Convert tokens to ids using the vocab.
        :param tokens: (list) tokens
        :return:
        """
        ids = []
        for token in tokens:
            ids.append(self.vocab.get(token, self.vocab['[UNK]']))
        if len(ids) > self.max_len:
            logger.warning("Token indices sequence length is longer than the specified maximum"
                           " sequence length for this BERT model ({} > {}). Running this"
                           " sequence through BERT will result in indexing errors".format(len(ids), self.max_len))
        return ids

    def convert_ids_to_tokens(self, ids):
        """
        Convert ids to tokens using the vocab.
        :param ids:
        :return:
        """
        tokens = [self.ids_to_tokens[i] for i in ids]
        return tokens

    def save_vocabulary(self, vocab_path):
        """
        Save the tokenizer vocabulary to a directory or file.
        :param vocab_path:
        :return:
        """
        index = 0
        if os.path.isdir(vocab_path):
            vocab_file = os.path.join(vocab_path, VOCAB_NAME)
        with open(vocab_file, 'w', encoding = 'utf-8') as writer:
            for token, token_index in sorted(self.vocab.items(), key = lambda kv: kv[1]):
                if index != token_index:
                    logger.warning("Saving vocablary to {}: vocabulary indices are not consecutive."
                                   " Please check that the vocabulary is not corrupted!".format(vocab_file))
                    index = token_index
                writer.write(token + u'\n')
                index += 1
        return vocab_file

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, *inputs, **kwargs):
        """
        Instantiate a PretrainedBertModel from a pre-trained model file.
        Download and cache the pre-trained model file if needed.
        :param pretrained_model_name_or_path:
        :param inputs:
        :param kwargs:
        :return:
        """
        resolved_vocab_file = os.path.join(pretrained_model_name_or_path, 'vocab.txt')
        max_len = 512
        kwargs['max_len'] = min(kwargs.get('max_len', int(1e12)), max_len)

        tokenizer = cls(resolved_vocab_file, *inputs, **kwargs)

        return tokenizer


def _run_strip_accents(text):
    """
    Strips accents from a piece of text.
    :param text:
    :return:
    """
    text = unicodedata.normalize('NFD', text)
    output = []
    for char in text:
        cat = unicodedata.category(char)
        if cat is 'Mn':
            continue
        output.append(char)
    return ''.join(output)


class BasicTokenizer(object):
    """
    Runs basic tokenization (punctuation splitting, lower casing, etc.
    """

    def __init__(self, do_lower_case=True, never_split=('[UNK]', '[SEP]', '[PAD]', '[CLS]', '[MASK]')):
        """
        Constructs a BasicTokenizer.
        :param do_lower_case:
        :param never_split:
        """
        self.do_lower_case = do_lower_case
        self.never_split = never_split

    def tokenize(self, text):
        """
        Tokenizes a piece of text.
        :param text:
        :return:
        """
        text = self._clean_text(text)
        text = self._tokenize_chinese_chars(text)
        orig_tokens = whitespace_tokenize(text)
        split_tokens = []
        for token in orig_tokens:
            if self.do_lower_case and token not in self.never_split:
                token = token.lower()
                token = _run_strip_accents(token)
            split_tokens.extend(self._run_split_on_punc(token))

        output_tokens = whitespace_tokenize(' '.join(split_tokens))
        return output_tokens

    def _run_split_on_punc(self, text):
        """
        Splits punctuation on a piece of text.
        :param text:
        :return:
        """
        if text in self.never_split:
            return [text]
        chars = list(text)
        i = 0
        start_new_word = True
        output = []
        while i < len(chars):
            char = chars[i]
            if _is_punctuation(char):
                output.append([char])
                start_new_word = True
            else:
                if start_new_word:
                    output.append([])
                start_new_word = False
                output[-1].append(char)
            i += 1

        return [''.join(x) for x in output]

    def _tokenize_chinese_chars(self, text):
        """
        Adds whitespace around any CJK character.
        :param text:
        :return:
        """
        output = []
        for char in text:
            cp = ord(char)
            if self._is_chinese_char(cp):
                output.append(' ')
                output.append(char)
                output.append(' ')
            else:
                output.append(char)
        return ''.join(output)

    def _is_chinese_char(self, cp):
        """
        Checks whether CP is the codepoint of a CJK character.
        :param cp:
        :return:
        """
        if ((0x4E00 <= cp <= 0x9FFF) or
                (0x3400 <= cp <= 0x4DBF) or
                (0x20000 <= cp <= 0x2A6DF) or
                (0x2A700 <= cp <= 0x2B73F) or
                (0x2B740 <= cp <= 0x2B81F) or
                (0x2B820 <= cp <= 0x2CEAF) or
                (0xF900 <= cp <= 0xFAFF) or
                (0x2F800 <= cp <= 0x2FA1F)):
            return True
        return False

    def _clean_text(self, text):
        """
        Performs invalid character removal and whitespace cleanup on text.
        :param text:
        :return:
        """
        output = []
        for char in text:
            cp = ord(char)
            if cp == 0 or cp == 0xfffd or _is_control(char):
                continue
            if _is_whitespace(char):
                output.append(' ')
            else:
                output.append(char)
        return ''.join(output)


class WordpieceTokenizer(object):
    """
    Runs wordpiece tokenization.
    """

    def __init__(self, vocab, unk_token='[UNK]', max_input_chars_per_word=100):
        self.vocab = vocab
        self.unk_token = unk_token
        self.max_input_chars_per_word = max_input_chars_per_word

    def tokenize(self, text):
        """
        Tokenizes a piece of text into its word pieces.
        :param text:
        :return:
        """
        output_tokens = []
        for token in whitespace_tokenize(text):
            chars = list(token)
            if len(chars) > self.max_input_chars_per_word:
                output_tokens.append(self.unk_token)
                continue

            is_bad = False
            start = 0
            sub_tokens = []
            while start < len(chars):
                end = len(chars)
                cur_substr = None
                while start < end:
                    substr = "".join(chars[start:end])
                    if start > 0:
                        substr = "##" + substr
                    if substr in self.vocab:
                        cur_substr = substr
                        break
                    end -= 1
                if cur_substr is None:
                    is_bad = True
                    break
                sub_tokens.append(cur_substr)
                start = end

            if is_bad:
                output_tokens.append(self.unk_token)
            else:
                output_tokens.extend(sub_tokens)

        return output_tokens


def _is_whitespace(char):
    """
    Checks whether `chars` is a whitespace character.
    :param char:
    :return:
    """
    if char == " " or char == "\t" or char == "\n" or char == "\r":
        return True
    cat = unicodedata.category(char)
    if cat == 'Zs':
        return True
    return False


def _is_control(char):
    """
    Checks whether `chars` is a control character.
    :param char:
    :return:
    """
    if char == "\t" or char == "\n" or char == "\r":
        return False
    cat = unicodedata.category(char)
    if cat.startswith('C'):
        return True
    return False


def _is_punctuation(char):
    """
    Checks whether `chars` is a punctuation character.
    :param char:
    :return:
    """
    cp = ord(char)
    if 33 <= cp <= 47 or 58 <= cp <= 64 or 91 <= cp <= 96 or 123 <= cp <= 126:
        return True
    cat = unicodedata.category(char)
    if cat.startswith('P'):
        return True
    return False
