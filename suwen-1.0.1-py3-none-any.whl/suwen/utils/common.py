# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import warnings

from mindspore import context
from mindspore.common.seed import set_seed

def initial_context(graph_mode=context.GRAPH_MODE, device_id=-1, device_target='Ascend', save_graphs=False, seed=None):
    if device_id == -1:
        warnings.warn("You have not set device id, and it turns to be zero for default.")
        device_id = 0

    if device_target not in ["Ascend"]:
        raise KeyError("Only Support Ascend Now!")
    context.set_context(mode = graph_mode, device_target = "Ascend", save_graphs = save_graphs,
                        device_id = int(device_id))
    if seed is not None:
        if not isinstance(seed, int):
            raise KeyError("seed should only be type of int.")
        set_seed(seed)
