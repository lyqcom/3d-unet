# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import mindspore.common.dtype as mstype
from mindspore import nn
from mindspore.nn.cell import Cell
from mindspore.ops import _selected_ops
from mindspore.ops import functional as F
from mindspore.ops import operations as P
from mindspore.common.tensor import Tensor
from mindspore.ops.primitive import constexpr
from mindspore._checkparam import Validator as validator
from mindspore.nn.layer.activation import get_activation

class _Loss(Cell):
    """
    Base class for other losses.
    """

    def __init__(self, reduction='mean'):
        super(_Loss, self).__init__()
        if reduction is None:
            reduction = 'none'

        if reduction not in ('mean', 'sum', 'none'):
            raise ValueError(f"reduction method for {reduction.lower()} is not supported")

        self.average = True
        self.reduce = True
        if reduction == 'sum':
            self.average = False
        if reduction == 'none':
            self.reduce = False

        self.reduce_mean = _selected_ops.ReduceMean()
        self.reduce_sum = P.ReduceSum()
        self.mul = P.Mul()
        self.cast = P.Cast()

    def get_axis(self, x):
        shape = F.shape(x)
        length = F.tuple_len(shape)
        perm = F.make_range(0, length)
        return perm

    def get_loss(self, x, weights=1.0):
        """
        Computes the weighted loss
        Args:
            weights: Optional `Tensor` whose rank is either 0, or the same rank as inputs, and must be broadcastable to
                inputs (i.e., all dimensions must be either `1`, or the same as the corresponding inputs dimension).
        """
        input_dtype = x.dtype
        x = self.cast(x, mstype.float32)
        weights = self.cast(weights, mstype.float32)
        x = self.mul(weights, x)
        if self.reduce and self.average:
            x = self.reduce_mean(x, self.get_axis(x))
        if self.reduce and not self.average:
            x = self.reduce_sum(x, self.get_axis(x))
        x = self.cast(x, input_dtype)
        return x

    def construct(self, base, target):
        raise NotImplementedError

class DiceLossHelper(_Loss):
    r"""
    The Dice coefficient is a set similarity loss. It is used to calculate the similarity between two samples. The
    value of the Dice coefficient is 1 when the segmentation result is the best and 0 when the segmentation result
    is the worst. The Dice coefficient indicates the ratio of the area between two objects to the total area.
    The function is shown as follows:

    .. math::
        dice = 1 - \frac{2 * (pred \bigcap true)}{pred \bigcup true}

    Args:
        smooth (float): A term added to the denominator to improve numerical stability. Should be greater than 0.
                        Default: 1e-5.

    Inputs:
        - **y_pred** (Tensor) - Tensor of shape (N, ...). The data type must be float16 or float32.
        - **y** (Tensor) - Tensor of shape (N, ...). The data type must be float16 or float32.

    Outputs:
        Tensor, a tensor of shape with the per-example sampled Dice losses.

    Supported Platforms:
        ``Ascend`` ``GPU`` ``CPU``

    Examples:
        >>> loss = nn.DiceLossHelper(smooth=1e-5)
        >>> y_pred = Tensor(np.array([[0.2, 0.5], [0.3, 0.1], [0.9, 0.6]]), mstype.float32)
        >>> y = Tensor(np.array([[0, 1], [1, 0], [0, 1]]), mstype.float32)
        >>> output = loss(y_pred, y)
        >>> print(output)
        [0.7953220862819745]

    Raises:
        ValueError: If the dimensions are different.
        TypeError: If the type of inputs are not Tensor.
    """

    def __init__(self, smooth=1e-5):
        super(DiceLossHelper, self).__init__()
        self.smooth = smooth
        self.reshape = P.Reshape()

    def construct(self, logits, label):
        _check_shape(logits.shape, label.shape)
        intersection = self.reduce_sum(self.mul(self.reshape(logits, (-1,)), self.reshape(label, (-1,))))
        unionset = self.reduce_sum(self.mul(self.reshape(logits, (-1,)), self.reshape(logits, (-1,)))) + \
                   self.reduce_sum(self.mul(self.reshape(label, (-1,)), self.reshape(label, (-1,))))

        single_dice_coeff = (2 * intersection) / (unionset + self.smooth)
        dice_loss = 1 - single_dice_coeff

        return dice_loss

@constexpr
def _check_shape(logits_shape, label_shape):
    validator.check('logits_shape', logits_shape, 'label_shape', label_shape)

@constexpr
def _check_weights(weight, label):
    if weight.shape[0] != label.shape[1]:
        raise ValueError("The shape of weight should be equal to the shape of label, but the shape of weight is {}, "
                         "and the shape of label is {}.".format(weight.shape, label.shape))

class MultiClassDiceLossHelper(_Loss):
    r"""
    When there are multiple classifications, label is transformed into multiple binary classifications by one hot.
    For each channel section in the channel, it can be regarded as a binary classification problem, so it can be
    obtained through the binary loss of each category, and then the average value.

    Args:
        weights (Union[Tensor, None]): Tensor of shape `[num_classes, dim]`.
        ignore_indiex (Union[int, None]): Class index to ignore.
        activation (Union[str, Cell]): Activate function applied to the output of the fully connected layer, eg. 'ReLU'.
                                       Default: 'Softmax'. Choose from:
                                       ['Softmax', 'LogSoftmax', 'ReLU', 'ReLU6', 'Tanh', 'GELU', 'FastGelu', 'Sigmoid',
                                        'PReLU', 'LeakyReLU', 'HSigmoid', 'HSwish', 'ELU', 'LogSigmoid']

    Inputs:
        - **y_pred** (Tensor) - Tensor of shape (N, ...). The data type must be float16 or float32.
        - **y** (Tensor) - Tensor of shape (N, ...). The data type must be float16 or float32.

    Outputs:
        Tensor, a tensor of shape with the per-example sampled MultiClass Dice Losses.

    Supported Platforms:
        ``Ascend`` ``GPU`` ``CPU``

    Examples:
        >>> loss = nn.MultiClassDiceLossHelper(weights=None, ignore_indiex=None, activation="softmax")
        >>> y_pred = Tensor(np.array([[0.2, 0.5], [0.3, 0.1], [0.9, 0.6]]), mstype.float32)
        >>> y = Tensor(np.array([[0, 1], [1, 0], [0, 1]]), mstype.float32)
        >>> output = loss(y_pred, y)
        >>> print(output)
        [0.7761003]

    Raises:
        ValueError: If the shapes are different.
        TypeError: If the type of inputs are not Tensor.
    """

    def __init__(self, weights=None, ignore_indiex=None, activation="softmax"):
        super(MultiClassDiceLossHelper, self).__init__()

        self.binarydiceloss = DiceLoss(smooth = 1e-5)
        self.weights = weights if weights is None else validator.check_value_type("weights", weights, [Tensor])
        self.ignore_indiex = ignore_indiex if ignore_indiex is None else \
            validator.check_value_type("ignore_indiex", ignore_indiex, [int])
        self.activation = get_activation(activation) if isinstance(activation, str) else activation
        if self.activation is not None and not isinstance(self.activation, Cell):
            raise TypeError("The activation must be str or Cell, but got {}.".format(activation))
        self.reshape = P.Reshape()

    def construct(self, logits, label):
        _check_shape(logits.shape, label.shape)
        total_loss = 0

        if self.activation is not None:
            logits = self.activation(logits)

        for i in range(label.shape[1]):
            if i != self.ignore_indiex:
                dice_loss = self.binarydiceloss(logits[:, i], label[:, i])
                if self.weights is not None:
                    _check_weights(self.weights, label)
                    dice_loss *= self.weights[i]
                total_loss += dice_loss

        return total_loss / label.shape[1]
