# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

from typing import Callable

import mindspore.nn as nn
from mindspore.ops import operations as P

class LayerFactory:
    """
    Factory object for creating layers, this uses given factory functions to actually produce the types or constructing
    callables. These functions are referred to by name and can be added at any time.
    For example, to get a transpose convolution layer the name is needed and then a dimension argument is provided which is
    passed to the factory function:

    .. code-block:: python

    dimension = 2
    name = Conv.CONVTRANS
    conv = Conv[name, dimension]

    """

    def __init__(self):
        self.factories = {}

    @property
    def names(self):
        """
        Produces all factory names.
        """
        return tuple(self.factories)

    def add_factory_callable(self, name, func):
        """
        Add the factory function to this object under the given name.
        """
        self.factories[name.upper()] = func

        self.__doc__ = (
                "The supported member"
                + ("s are: " if len(self.names) > 1 else " is: ")
                + ", ".join(f"``{name}``" for name in self.names)
                + ".\nPlease see :py:class:`suwen.networks.layers.split_args` for additional args parsing."
        )

    def factory_function(self, name):
        """
        Decorator for adding a factory function with the given name.
        """

        def _add(func):
            self.add_factory_callable(name, func)
            return func

        return _add

    def get_constructor(self, factory_name, *args):
        """
        Get the constructor for the given factory name and arguments.
        Raises:
            TypeError: When ``factory_name`` is not a ``str``.
        """
        if not isinstance(factory_name, str):
            raise TypeError(f"factory_name must a str but is {type(factory_name).__name__}.")

        fact = self.factories[factory_name.upper()]

        return fact(*args)

    def __getitem__(self, args):
        """
        Get the given name or name/arguments pair. If `args` is a callable it is assumed to be the constructor
        itself and is returned, otherwise it should be the factory name or a pair containing the name and arguments.
        """

        if callable(args):
            return args

        if isinstance(args, str):
            name_obj, args = args, ()
        else:
            name_obj, *args = args

        return self.get_constructor(name_obj, *args)

    def __getattr__(self, key):
        """
        If `key` is a factory name, return it, otherwise behave as inherited. This allows referring to factory names
        as if they were constants, eg. `Fact.FOO` for a factory Fact with factory function foo.
        """
        if key in self.factories:
            return key

        return super().__getattribute__(key)

def split_args(args):
    """
    Split arguments in a way to be suitable for using with the factory types. If `args` is a string it's interpreted as
    the type name.
    Args:
        args (str or a tuple of object name and kwarg dict): input arguments to be parsed.
    Raises:
        TypeError: When ``args`` type is not in ``Union[str, Tuple[Union[str, Callable], dict]]``.
    Examples::
        >>> act_type, args = split_args("PRELU")
        >>> suwen.networks.layers.Act[act_type]
        
        >>> act_type, args = split_args(("PRELU", {"num_parameters": 1, "init": 0.25}))
        >>> suwen.networks.layers.Act[act_type](**args)
        PReLU(num_parameters=1)
    """

    if isinstance(args, str):
        return args, {}
    name_obj, name_args = args

    if not isinstance(name_obj, (str, Callable)) or not isinstance(name_args, dict):
        msg = "Layer specifiers must be single strings or pairs of the form (name/object-types, argument dict)"
        raise TypeError(msg)

    return name_obj, name_args

Conv = LayerFactory()
Norm = LayerFactory()
Dropout = LayerFactory()
Pool = LayerFactory()
Pad = LayerFactory()

Act = LayerFactory()
Act.add_factory_callable("elu", lambda: nn.ELU)
Act.add_factory_callable("fastgelu", lambda: nn.FastGelu)
Act.add_factory_callable("gelu", lambda: nn.GELU)
Act.add_factory_callable("hsigmoid", lambda: nn.HSigmoid)
Act.add_factory_callable("hswish", lambda: nn.HSwish)
Act.add_factory_callable("leakyrelu", lambda: nn.LeakyReLU)
Act.add_factory_callable("logsigmoid", lambda: nn.LogSigmoid)
Act.add_factory_callable("logsoftmax", lambda: nn.LogSoftmax)
Act.add_factory_callable("prelu", lambda: nn.PReLU)
Act.add_factory_callable("relu", lambda: nn.ReLU)
Act.add_factory_callable("relu6", lambda: nn.ReLU6)
Act.add_factory_callable("sigmoid", lambda: nn.Sigmoid)
Act.add_factory_callable("softmax", lambda: nn.Softmax)
Act.add_factory_callable("tanh", lambda: nn.Tanh)

Pad.add_factory_callable("pad", lambda: nn.Pad)

@Conv.factory_function("conv")
def conv_factory(dim):
    types = (nn.Conv1d, nn.Conv2d)
    return types[dim - 1]

@Conv.factory_function("convtrans")
def convtrans_factory(dim):
    types = (nn.Conv1dTranspose, nn.Conv2dTranspose)
    return types[dim - 1]

@Norm.factory_function("batch")
def batch_factory(dim):
    types = (nn.BatchNorm1d, nn.BatchNorm2d)
    return types[dim - 1]

@Norm.factory_function("group")
def group_factory():
    return nn.GroupNorm

@Norm.factory_function("layer")
def layer_factory():
    return nn.LayerNorm

@Dropout.factory_function("dropout")
def dropout_factory(dim):
    types = (nn.Dropout, nn.Dropout)
    return types[dim - 1]

@Pool.factory_function("avg")
def avgpooling_factory(dim):
    types = (nn.AvgPool1d, nn.AvgPool2d)
    return types[dim - 1]

@Pool.factory_function("max")
def maxpooling_factory(dim):
    types = (nn.MaxPool2d, nn.MaxPool2d)
    return types[dim - 1]
