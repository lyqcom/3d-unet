# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import mindspore.nn as nn
from mindspore.ops import operations as P
from mindspore.common.initializer import TruncatedNormal

from suwen.algorithm.layers.factories import Act, Norm, Conv

class ResidualUnit(nn.Cell):
    """
    Residual module with multiple convolutions and a residual connection.

    Args:
        in_channels: number of input channels.
        out_channels: number of output channels.
        strides: convolution stride. Defaults to 2.
        down: default True
        out_layer: default False
    """

    def __init__(self, in_channels, out_channels, stride=2, down=True, out_layer=False):
        super().__init__()
        self.out_layer = out_layer
        self.down = down
        init_value_0 = TruncatedNormal(0.06)
        init_value_1 = TruncatedNormal(0.06)
        init_value_2 = TruncatedNormal(0.06)
        if out_layer:
            self.conv1 = Conv[Conv.CONV, 2](in_channels, out_channels, kernel_size = 3, stride = stride,
                                            has_bias = True,
                                            weight_init = init_value_0, pad_mode = 'pad', padding = 1)
        else:
            self.conv1 = nn.SequentialCell(
                [Conv[Conv.CONV, 2](in_channels, out_channels, kernel_size = 3, stride = stride, has_bias = True,
                                    weight_init = init_value_0, pad_mode = "pad", padding = 1),
                 Norm[Norm.BATCH, 2](out_channels, momentum = 0.1),
                 Act[Act.RELU]()]
            )

        self.conv2 = nn.SequentialCell(
            [Conv[Conv.CONV, 2](out_channels, out_channels, kernel_size = 3, stride = 1, has_bias = True,
                                weight_init = init_value_1, pad_mode = "pad", padding = 1),
             Norm[Norm.BATCH, 2](out_channels, momentum = 0.1),
             Act[Act.RELU]()]
        )

        self.residual = Conv[Conv.CONV, 2](in_channels, out_channels, kernel_size = 3, stride = stride, has_bias = True,
                                           weight_init = init_value_2, pad_mode = "pad", padding = 1)

    def construct(self, x):
        out = self.conv1(x)
        if self.down:
            out = self.conv2(out)
            res_out = self.residual(x)
        else:
            res_out = x
        return out + res_out

class Down(nn.Cell):
    """
    Downscaling with maxpool then double conv.

    Args:
        in_channels (int): Input channel.
        out_channels (int): Output channel.

    Returns:
        Tensor, output tensor.
    """

    def __init__(self, in_channels, out_channels, stride=2):
        super().__init__()
        self.down = ResidualUnit(in_channels, out_channels, stride = stride, down = True)

    def construct(self, x):
        out = self.down(x)
        return out

class Up(nn.Cell):
    """
    Upscaling then double conv.

    Args:
        in_channels (int): Input channel.
        out_channels (int): Output channel.

    Returns:
        Tensor, output tensor.
    """

    def __init__(self, in_channels, down_in_channels, out_channels, out_layer=False):
        super().__init__()
        self.cast = P.Cast()
        self.concat = P.Concat(axis = 1)
        self.conv_trans = nn.SequentialCell(
            [Conv[Conv.CONVTRANS, 2](in_channels + down_in_channels, out_channels, kernel_size = 3,
                                     stride = 2, pad_mode = 'same'),
             Norm[Norm.BATCH, 2](out_channels, momentum = 0.1),
             Act[Act.RELU]()]
        )
        self.residual = ResidualUnit(out_channels, out_channels, stride = 1, down = False, out_layer = out_layer)

    def construct(self, input_data, down_input):
        x = self.concat((input_data, down_input))
        x = self.conv_trans(x)
        out = self.residual(x)
        return out
