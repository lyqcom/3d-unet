# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import mindspore.nn as nn

from suwen.algorithm.blocks.NDA import NDA
from suwen.algorithm.layers.factories import Conv

class Convolution(nn.SequentialCell):
    """
    Constructs a convolution with normalization, optional dropout, and optional activation layers::

        -- (Conv|ConvTrans) -- (Norm -- Dropout -- Acti) --

    if ``conv_only`` set to ``True``::

        -- (Conv|ConvTrans) --

    Args:
        dimensions: number of spatial dimensions.
        in_channels: number of input channels.
        out_channels: number of output channels.
        strides: convolution stride. Defaults to 1.
        kernel_size: convolution kernel size. Defaults to 3.
        nda_ordering: a string representing the ordering of activation, normalization, and dropout.
            Defaults to "NDA".
        act: activation type and arguments. Defaults to PReLU.
        norm: feature normalization type and arguments. Defaults to batch norm.
        dropout: dropout ratio. Defaults to no dropout.
        dilation: dilation rate. Defaults to 1.
        groups: controls the connections between inputs and outputs. Defaults to 1.
        has_bias: whether to have a bias term. Defaults to True.
        conv_only: whether to use the convolutional layer only. Defaults to False.
        is_transposed: if True uses ConvTrans instead of Conv. Defaults to False.
        padding: controls the amount of implicit zero-paddings on both sides for padding number of points
            for each dimension. Defaults to None.
        pad_mode: Specifies padding mode. The optional values are “same”, “valid”, “pad”. Default: “same”.
        weight_init:  Initializer for the convolution kernel. It can be a Tensor, a string, an Initializer or a number. When a string is specified, values from ‘TruncatedNormal’, ‘Normal’, ‘Uniform’, ‘HeUniform’ and ‘XavierUniform’ distributions as well as constant ‘One’ and ‘Zero’ distributions are possible. Alias ‘xavier_uniform’, ‘he_uniform’, ‘ones’ and ‘zeros’ are acceptable. Uppercase and lowercase are both acceptable. Refer to the values of Initializer for more details. Default: ‘normal’.
        bias_init: Initializer for the bias vector. Possible Initializer and string are the same as ‘weight_init’. Refer to the values of Initializer for more details. Default: ‘zeros’.
    """

    def __init__(self,
                 dimensions,
                 in_channels,
                 out_channels,
                 strides=1,
                 kernel_size=3,
                 nda_ordering="NDA",
                 act="PRelu",
                 norm="Batch",
                 dropout=None,
                 dilation=1,
                 group=1,
                 has_bias=True,
                 conv_only=False,
                 is_transposed=False,
                 padding=0,
                 pad_mode='same',
                 weight_init='normal',
                 bias_init='zeros',
                 ):
        super(Convolution, self).__init__()
        self.dimensions = dimensions
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.is_transposed = is_transposed
        conv_type = Conv[Conv.CONVTRANS if is_transposed else Conv.CONV, dimensions]
        conv = conv_type(
            in_channels,
            out_channels,
            kernel_size = kernel_size,
            stride = strides,
            pad_mode = pad_mode,
            padding = padding,
            dilation = dilation,
            group = group,
            has_bias = has_bias,
            weight_init = weight_init,
            bias_init = bias_init,
        )
        self.append(conv)
        if not conv_only:
            self.append(
                NDA(
                    ordering = nda_ordering,
                    in_channels = out_channels,
                    act = act,
                    norm = norm,
                    norm_dim = dimensions,
                    dropout = dropout,
                ))
