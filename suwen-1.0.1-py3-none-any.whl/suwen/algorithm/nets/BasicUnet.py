# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import mindspore.nn as nn
import mindspore.ops as ops

from suwen.algorithm.blocks.Convolution import Convolution
from suwen.algorithm.layers.factories import Conv, Pool

class TwoConv(nn.SequentialCell):
    """
    two convolutions.
    """

    def __init__(self, dim, in_chns, out_chns, act="RELU", norm=None, dropout=1.0):
        """
        Args:
            dim: number of spatial dimensions.
            in_chns: number of input channels.
            out_chns: number of output channels.
            act: activation type and arguments.
            norm: feature normalization type and arguments.
            dropout: dropout ratio. Defaults to no dropout.
        """
        super().__init__()

        conv_0 = Convolution(dim, in_chns, out_chns, act = act, norm = norm, dropout = dropout)
        conv_1 = Convolution(dim, out_chns, out_chns, act = act, norm = norm, dropout = dropout)
        self.append(conv_0)
        self.append(conv_1)

class Down(nn.SequentialCell):
    """
    avgpooling downsampling and two convolutions.
    """

    def __init__(self, dim, in_chns, out_chns, act, norm, dropout=1.0):
        """
        Args:
            dim: number of spatial dimensions.
            in_chns: number of input channels.
            out_chns: number of output channels.
            act: activation type and arguments.
            norm: feature normalization type and arguments.
            dropout: dropout ratio. Defaults to no dropout.
        """
        super().__init__()

        max_pooling = Pool["MAX", dim](kernel_size = 2, stride = 2)
        convs = TwoConv(dim, in_chns, out_chns, act, norm, dropout)
        self.append(max_pooling)
        self.append(convs)

class UpCat(nn.Cell):
    """
    upsampling, concatenation with the encoder feature map, two convolutions
    """

    def __init__(self, dim, in_chns, cat_chns, out_chns, act, norm,
                 dropout=1.0, halves=True, is_transposed=True, conv_only=True):
        """
        Args:
            dim: number of spatial dimensions.
            in_chns: number of input channels to be upsampled.
            cat_chns: number of channels from the decoder.
            out_chns: number of output channels.
            act: activation type and arguments.
            norm: feature normalization type and arguments.
            dropout: dropout ratio. Defaults to no dropout.
            halves: whether to halve the number of channels during upsampling.
        """
        super().__init__()
        self.concat = ops.Concat(axis = 1)
        up_chns = in_chns // 2 if halves else in_chns
        self.upsample = Convolution(dim, in_chns, up_chns, kernel_size = 2, strides = 2, is_transposed = True,
                                    conv_only = True)
        self.convs = TwoConv(dim, cat_chns + up_chns, out_chns, act, norm, dropout)

    def construct(self, x, x_e):
        """
        Args:
            x: features to be upsampled.
            x_e: features from the encoder.
        """
        x_0 = self.upsample(x)
        x = self.convs(self.concat((x_e, x_0)))
        return x

class BasicUNet(nn.Cell):
    def __init__(
            self,
            dimensions=3,
            in_channels=1,
            out_channels=2,
            features=(32, 32, 64, 128, 256, 32),
            act="RELU",
            norm="BATCH",
            dropout=1.0,
    ):
        """
        A UNet implementation with 1D/2D/3D supports.
        Args:
            dimensions: number of spatial dimensions. Defaults to 3 for spatial 3D inputs.
            in_channels: number of input channels. Defaults to 1.
            out_channels: number of output channels. Defaults to 2.
            features: six integers as numbers of features.
                Defaults to ``(32, 32, 64, 128, 256, 32)``,
                - the first five values correspond to the five-level encoder feature sizes.
                - the last value corresponds to the feature size after the last upsampling.
            act: activation type and arguments. Defaults to ReLU.
            norm: feature normalization type and arguments. Defaults to batch norm.
            dropout: dropout ratio. Defaults to no dropout.`
        Examples::
            # for spatial 2D
            >>> net = BasicUNet(dimensions=2, features=(64, 128, 256, 512, 1024, 128))
            # for spatial 2D, with group norm
            >>> net = BasicUNet(dimensions=2, features=(64, 128, 256, 512, 1024, 128), norm=("group", {"num_groups": 4}))
            # for spatial 3D
            >>> net = BasicUNet(dimensions=3, features=(32, 32, 64, 128, 256, 32))
        """
        super().__init__()

        self.conv_0 = TwoConv(dimensions, in_channels, features[0], act, norm, dropout)
        self.down_1 = Down(dimensions, features[0], features[1], act, norm, dropout)
        self.down_2 = Down(dimensions, features[1], features[2], act, norm, dropout)
        self.down_3 = Down(dimensions, features[2], features[3], act, norm, dropout)
        self.down_4 = Down(dimensions, features[3], features[4], act, norm, dropout)

        self.upcat_4 = UpCat(dimensions, features[4], features[3], features[3], act, norm, dropout)
        self.upcat_3 = UpCat(dimensions, features[3], features[2], features[2], act, norm, dropout)
        self.upcat_2 = UpCat(dimensions, features[2], features[1], features[1], act, norm, dropout)
        self.upcat_1 = UpCat(dimensions, features[1], features[0], features[5], act, norm, dropout)

        self.final_conv = Conv["conv", dimensions](features[5], out_channels, kernel_size = 1)

    def construct(self, x):
        """
        Args:
            x: input should have spatially N dimensions
                ``(Batch, in_channels, dim_0[, dim_1, ..., dim_N])``, N is defined by `dimensions`.
                It is recommended to have ``dim_n % 16 == 0`` to ensure all maxpooling inputs have
                even edge lengths.
        Returns:
            A mindspore Tensor of "raw" predictions in shape
            ``(Batch, out_channels, dim_0[, dim_1, ..., dim_N])``.
        """
        x0 = self.conv_0(x)
        x1 = self.down_1(x0)
        x2 = self.down_2(x1)
        x3 = self.down_3(x2)
        x4 = self.down_4(x3)
        u4 = self.upcat_4(x4, x3)
        u3 = self.upcat_3(u4, x2)
        u2 = self.upcat_2(u3, x1)
        u1 = self.upcat_1(u2, x0)
        logits = self.final_conv(u1)

        return logits

BasicUnet = Basicunet = BasicUNet
