# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import mindspore.nn as nn
from mindspore.ops import operations as P
from mindspore.common.tensor import Tensor
from mindspore.common import dtype as mstype
from mindspore.common.initializer import TruncatedNormal

from suwen.algorithm.blocks.bert_mode import BertModel
from suwen.algorithm.layers.factories import Dropout

GRADIENT_CLIP_TYPE = 1
GRADIENT_CLIP_VALUE = 1.0

class CrossEntropyWithLogits(nn.Cell):
    """
    Cross Entropy loss for BERT
    """
    def __init__(self, is_training=True):
        super(CrossEntropyWithLogits, self).__init__()
        self.onehot = P.OneHot()
        self.on_value = Tensor(1.0, mstype.float32)
        self.off_value = Tensor(0.0, mstype.float32)
        self.reduce_sum = P.ReduceSum()
        self.reduce_mean = P.ReduceMean()
        self.reshape = P.Reshape()
        self.last_idx = (-1,)
        self.neg = P.Neg()
        self.cast = P.Cast()
        self.is_training = is_training

    def construct(self, logits, label_ids, input_mask, num_labels, task='classifier'):
        if self.is_training:
            label_ids = self.reshape(label_ids, self.last_idx)
            one_hot_labels = self.onehot(label_ids, num_labels, self.on_value, self.off_value)
            per_example_loss = self.neg(self.reduce_sum(one_hot_labels * logits, self.last_idx))
            loss = self.reduce_mean(per_example_loss, self.last_idx)
            return_value = self.cast(loss, mstype.float32)
        else:
            return_value = logits * 1.0
        return return_value

class BertCLSModel(nn.Cell):
    """
    This class is responsible for classification task evaluation.

    Args:
        config (BertConfig): The config of Bert.
        is_training (bool): Whether to use for training or evaling.
        num_labels (int): Class number.
        dropout_prob (float): Probability of dropout op.
        use_one_hot_embeddings (bool): Whether to use one hot embedding.

    Returns:
        Tensor, represents the final logits as the results of log_softmax is propotional to that of softmax.
    """
    def __init__(self, config, is_training, num_labels=2, dropout_prob=0.0, use_one_hot_embeddings=False):
        super(BertCLSModel, self).__init__()
        if not is_training:
            config.hidden_dropout_prob = 0.0
            config.hidden_probs_dropout_prob = 0.0
        self.bert = BertModel(config, is_training, use_one_hot_embeddings)
        self.cast = P.Cast()
        self.weight_init = TruncatedNormal(config.initializer_range)
        self.log_softmax = P.LogSoftmax(axis=-1)
        self.dtype = config.dtype
        self.num_labels = num_labels
        self.dense_1 = nn.Dense(config.hidden_size, self.num_labels, weight_init=self.weight_init,
                                has_bias=True).to_float(config.compute_type)
        self.dropout = Dropout[Dropout.DROPOUT, 1](1 - dropout_prob)

    def construct(self, input_ids, input_mask, token_type_id):
        _, pooled_output, _ = \
            self.bert(input_ids, token_type_id, input_mask)
        cls = self.cast(pooled_output, self.dtype)
        cls = self.dropout(cls)
        logits = self.dense_1(cls)
        logits = self.cast(logits, self.dtype)
        logits = self.log_softmax(logits)
        return logits

class BertNERModel(nn.Cell):
    """
    This class is responsible for sequence labeling task evaluation.

    Args:
        config (BertConfig): The config of Bert.
        is_training (bool): Whether to use for training or evaling.
        num_labels (int): Class number.
        dropout_prob (float): Probability of dropout op.
        use_one_hot_embeddings (bool): Whether to use one hot embedding.

    Returns:
        Tensor, represents the final logits as the results of log_softmax is propotional to that of softmax.
    """
    def __init__(self, config, is_training, num_labels=11, dropout_prob=0.0,
                 use_one_hot_embeddings=False):
        super(BertNERModel, self).__init__()
        if not is_training:
            config.hidden_dropout_prob = 0.0
            config.hidden_probs_dropout_prob = 0.0
        self.bert = BertModel(config, is_training, use_one_hot_embeddings)
        self.cast = P.Cast()
        self.weight_init = TruncatedNormal(config.initializer_range)
        self.log_softmax = P.LogSoftmax(axis=-1)
        self.dtype = config.dtype
        self.num_labels = num_labels
        self.dense_1 = nn.Dense(config.hidden_size, self.num_labels, weight_init=self.weight_init,
                                has_bias=True).to_float(config.compute_type)
        self.dropout = Dropout[Dropout.DROPOUT, 1](1 - dropout_prob)
        self.reshape = P.Reshape()
        self.shape = (-1, config.hidden_size)
        self.origin_shape = (-1, config.seq_length, self.num_labels)

    def construct(self, input_ids, input_mask, token_type_id):
        """Return the final logits as the results of log_softmax."""
        sequence_output, _, _ = \
            self.bert(input_ids, token_type_id, input_mask)
        seq = self.dropout(sequence_output)
        seq = self.reshape(seq, self.shape)
        logits = self.dense_1(seq)
        logits = self.cast(logits, self.dtype)
        return_value = self.log_softmax(logits)
        return return_value

class BertNER(nn.Cell):
    """
    Train interface for sequence labeling finetuning task.

    Args:
        config (BertConfig): The config of BertModel.
        batch_size (int): Batch size.
        is_training (bool): Whether to use for training or evaling.
        num_labels (int): Class number.
        use_crf (bool): Whether to use CRF as loss function.
        tag_to_index (list): Tag for index.
        dropout_prob (float): Probability of dropout op.
        use_one_hot_embeddings (bool): Whether to use one hot embedding.

    Returns:
        Tensor, loss.
    """
    def __init__(self, config, is_training, num_labels=11,
                 dropout_prob=0.0, task='classifier', use_one_hot_embeddings=False):
        super(BertNER, self).__init__()
        self.bert = BertNERModel(config, is_training, num_labels, dropout_prob, use_one_hot_embeddings)
        self.loss = CrossEntropyWithLogits(is_training)
        self.num_labels = num_labels
        self.task = task

    def construct(self, input_ids, input_mask, token_type_id, label_ids):
        logits = self.bert(input_ids, input_mask, token_type_id)
        loss = self.loss(logits, label_ids, input_mask, self.num_labels, self.task)
        return loss

class BertCLS(nn.Cell):
    """
    Train interface for classification finetuning task.

    Args:
        config (BertConfig): The config of BertModel.
        is_training (bool): Whether to use for training or evaling.
        num_labels (int): Class number.
        dropout_prob (float): Probability of dropout op.
        use_one_hot_embeddings (bool): Whether to use one hot embedding.

    Returns:
        Tensor, loss.
    """
    def __init__(self, config, is_training, num_labels=2, dropout_prob=0.0, use_one_hot_embeddings=False):
        super(BertCLS, self).__init__()
        self.bert = BertCLSModel(config, is_training, num_labels, dropout_prob, use_one_hot_embeddings)
        self.loss = CrossEntropyWithLogits(is_training)
        self.num_labels = num_labels
        self.is_training = is_training

    def construct(self, input_ids, input_mask, token_type_id, label_ids):
        logits = self.bert(input_ids, input_mask, token_type_id)
        loss = self.loss(logits, label_ids, input_mask, self.num_labels)
        return loss



