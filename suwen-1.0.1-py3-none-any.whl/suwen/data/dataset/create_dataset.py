# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

from PIL import Image

import mindspore.dataset as ds

from suwen.transforms.vision import NibabelReader, PILReader

class DatasetGenerator():
    """
    create general image dataset generator.

    Args:
        dict_data ([dictionary]): a list of dictionary data_path
        load_image
    Returns:
        dataset generator.
    """

    def __init__(self, dict_data, load_image, gray_scale, image_type='pil'):
        self.dict_data = dict_data
        self.keys = list(dict_data[0].keys())
        if image_type.lower() == 'pil':
            pil_mode = 'L' if gray_scale else 'RGB'
            converter = lambda image: image.convert(pil_mode)
            self.reader = PILReader(converter).read
        elif image_type.lower() in ['nifti', 'nii', 'nii.gz']:
            self.reader = NibabelReader().read_as_numpy

        if isinstance(load_image, bool):
            self.load_image = [load_image for i in range(len(self.keys))]
        elif isinstance(load_image, tuple) or isinstance(load_image, list):
            self.load_image = load_image
        else:
            raise ValueError("'load_image' should be a bool or list or tuple, got {}.".format(type(load_image)))

    def __getitem__(self, index):
        items = tuple(self.reader(self.dict_data[index][self.keys[idx]])
                      if idx < len(self.load_image) and self.load_image[idx]
                      else self.dict_data[index][self.keys[idx]]
                      for idx in range(len(self.keys))
                      )
        return items if len(items) > 1 else items[0]

    def __len__(self):
        return len(self.dict_data)

class DatasetGenerator2D():
    """
    create dataset generator for 2D U-Net.

    Args:
        dict_data: a list of dictionary data_path
    Returns:
        dataset generator.
    """

    def __init__(self, dict_data, load_image, gray_scale):
        self.dict_data = dict_data
        self.keys = list(dict_data[0].keys())
        self.color_mode = 'L' if gray_scale else 'RGB'
        if isinstance(load_image, bool):
            self.load_image = [load_image for i in range(len(self.keys))]
        elif isinstance(load_image, tuple) or isinstance(load_image, list):
            self.load_image = load_image
        else:
            raise ValueError("'load_image' should be a bool or list or tuple, got {}.".format(type(load_image)))

    def __getitem__(self, index):
        items = tuple(Image.open(self.dict_data[index][self.keys[idx]]).convert(self.color_mode)
                      if idx < len(self.load_image) and self.load_image[idx]
                      else self.dict_data[index][self.keys[idx]]
                      for idx in range(len(self.keys))
                      )
        return items if len(items) > 1 else items[0]

    def __len__(self):
        return len(self.dict_data)

def create_dataset(dict_data, transforms=[], common_transforms=[], batch_size=1, shuffle=False, gray_scale=False,
                   load_image=True, image_type='pil'):
    """
    create dataset for images.
    
    Args:
        dict_data ([dictionary]): a list of dictionary data_path
        transforms ([Transformer], optional): transforms apply to input data
        common_transform ([Transformer], optional): common transforms apply to all columns separetely
        batch_size (int, optional): batch size
        shuffle (bool, optional): whether or not to perform shuffle on the dataset. Random accessible input is required.
        gray_scale (bool, optional): if the image is read in gray_scale
        load_image ([bool], optional): a bool or list or tuple indicating whether load image or use the raw data, 
              default is True and load all columns as image
        image_type (str, optional): type of image to be loaded, currently available type: ['pil', 'nifti']
        
    Examples:
        >>> data = [{'img': './data/imgs/lesion_0.png', 'label': 0},
                    {'img': './data/imgs/normal_0.png', 'label': 1}]
        >>> transforms = [
        ...                 AddChannel(index=[0]),
        ...                 ToOneHot(index=[1], num_classes=2), 
        ...                 RandSpatialCrop(index=[0], roi_size=[224, 224]),
        ...                 ToNumpy(index=[0, 1])
        ...              ]
        >>> train_dataset = create_dataset(data, transforms=transforms, batch_size=2, gray_scale=True, load_image=(True, False))
        >>> for i in train_dataset.create_dict_iterator():
        >>>     print(i)
    """

    column_names = list(dict_data[0].keys())
    generator = DatasetGenerator(dict_data, load_image, gray_scale, image_type)
    dataset = ds.GeneratorDataset(generator, column_names, shuffle = shuffle)

    if common_transforms:
        for input_column in column_names:
            dataset = dataset.map(common_transforms, input_columns = input_column)

    elif transforms:
        dataset = dataset.map(transforms, input_columns = column_names)

    dataset = dataset.batch(batch_size)
    return dataset

def create_2d_dataset(dict_data, transforms=[], common_transforms=[], batch_size=1, shuffle=False, gray_scale=False,
                      load_image=True):
    """
    create dataset for 2D images.
    
    Args:
        dict_data ([dictionary]): a list of dictionary data_path
        transforms ([Transformer], optional): transforms apply to input data
        common_transform ([Transformer], optional): common transforms apply to all columns separetely
        batch_size (int, optional): batch size
        shuffle (bool, optional): whether or not to perform shuffle on the dataset. Random accessible input is required.
        gray_scale (bool, optional): if the image is read in gray_scale
        load_image ([bool], optional): a bool or list or tuple indicating whether load image or use the raw data, 
              default is True and load all columns as image
        
    Examples:
        >>> data = [{'img': './data/imgs/lesion_0.png', 'label': 0},
                    {'img': './data/imgs/normal_0.png', 'label': 1}]
        >>> transforms = [
        ...                 AddChannel(index=[0]),
        ...                 ToOneHot(index=[1], num_classes=2), 
        ...                 RandSpatialCrop(index=[0], roi_size=[224, 224]),
        ...                 ToNumpy(index=[0, 1])
        ...              ]
        >>> train_dataset = create_dataset(data, transforms=transforms, batch_size=2, gray_scale=True, load_image=(True, False))
        >>> for i in train_dataset.create_dict_iterator():
        >>>     print(i)
    """

    column_names = list(dict_data[0].keys())
    generator = DatasetGenerator2D(dict_data, load_image, gray_scale)
    dataset = ds.GeneratorDataset(generator, column_names, shuffle = shuffle)

    if common_transforms:
        for input_column in column_names:
            dataset = dataset.map(common_transforms, input_columns = input_column)

    elif transforms:
        dataset = dataset.map(transforms, input_columns = column_names)

    dataset = dataset.batch(batch_size)
    return dataset
