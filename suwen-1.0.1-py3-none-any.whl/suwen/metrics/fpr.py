# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import numpy as np

from mindspore.nn.metrics import Metric

class FPR(Metric):
    r"""
    Calculate False Positive Rate.

    math::
        fpr = FPR = FP / (FP + TN);

    Args:
        use_crf: whether to use the crf. Default: False.
        num_labels: number of labels. Default: 2
    """

    def __init__(self, metric_name="F1", num_labels=2, skip_channel=False):
        self.TP = 0
        self.FP = 0
        self.FN = 0
        self.TN = 0
        self.P = 0
        self.AP = 0
        self.num_labels = num_labels
        self.metric_name = metric_name
        self.skip_channel = skip_channel
        self.clear()

    def clear(self):
        """
        Clears the internal evaluation result.
        """
        self.TP = 0
        self.FP = 0
        self.FN = 0
        self.TN = 0
        self.P = 0
        self.AP = 0

    def update(self, logits, labels):
        """
        update FPR score
        """
        labels = labels.asnumpy()
        labels = np.reshape(labels, -1)

        logits = logits.asnumpy()
        logit_id = np.argmax(logits, axis = -1)
        logit_id = np.reshape(logit_id, -1)

        if self.num_labels == 2:
            pred = np.isin(logit_id, [i for i in range(1, 2)])
            label = np.isin(labels, [i for i in range(1, 2)])

            self.TP += np.sum(pred & label)
            self.FP += np.sum(pred & (~label))
            self.FN += np.sum((~pred) & label)
            self.TN += np.sum((~pred) & (~label))
        else:
            target = np.zeros((len(labels), self.num_labels), dtype = np.int)
            pred = np.zeros((len(logit_id), self.num_labels), dtype = np.int)
            for i, label in enumerate(labels):
                target[i][label] = 1
            for i, label in enumerate(logit_id):
                pred[i][label] = 1

            positives = pred.sum(axis = 0)
            actual_positives = target.sum(axis = 0)
            true_positives = (target * pred).sum(axis = 0)
            self.TP += true_positives
            self.P += positives
            self.AP += actual_positives

    def eval(self):
        """
        Calculate fpr
        """
        if self.num_labels == 2:
            if self.metric_name.lower() == 'f1':
                result = 2.0 * self.TP / (2.0 * self.TP + self.FN + self.FP)
            if self.metric_name.lower() in ['acc', 'accuracy']:
                result = (self.TP + self.TN) / (self.TP + self.TN + self.FP + self.FN)
        else:
            tp = np.sum(self.TP[1:]) if self.skip_channel else np.sum(self.TP)
            p = np.sum(self.P[1:]) if self.skip_channel else np.sum(self.P)
            ap = np.sum(self.AP[1:]) if self.skip_channel else np.sum(self.AP)
            result = 2 * tp / (ap + p)
        return result
