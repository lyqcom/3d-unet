# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import time

from mindspore import log as logger
from mindspore.train.callback import Callback

class FormatPrint(Callback):
    def __init__(self):
        pass

    def epoch_begin(self, run_context):
        print("## epoch start ##")

    def epoch_end(self, run_context):
        pass

class MetricCallback(Callback):
    """
    Metric Callback function will execute compute metric when every epoch completed, and print related message.
    model: after Model compile network.
    val_dataset: Dataset to evaluate the model.
    metric_name: The name of metric method
    epoch:  Total number of iterations on the data.
    """

    def __init__(self, model=None, val_dataset=None, metric_name="", epoch=None):
        self.model = model
        self.val_dataset = val_dataset
        self.metric_name = metric_name
        self.epoch_size = epoch
        self.epoch_num = 0
        self.epoch_time = 0
        self._check_variable()

    def update_model(self, model):
        self.model = model

    def _check_variable(self):
        if self.epoch_size is None:
            self.epoch_size = 1
            logger.warning("when epoch is None,it is automatic set to 1")
        if self.epoch_size < 0 or self.epoch_size == 0:
            raise ValueError("The epoch must be positive, but got epoch {}.".format(self.epoch_size))
        if not self.metric_name:
            raise RuntimeError('If define `valid_dataset`, metric fn can not be None or empty.')

    def epoch_begin(self, run_context):
        self.epoch_num += 1
        self.epoch_time = time.time()

    def epoch_end(self, run_context):
        cur_time = time.time()
        val_metric = self.model.eval(self.val_dataset)[self.metric_name]
        val_time = int(time.time() - cur_time)

        print(" Epoch {}/{}, Eval_{}:{}, EvalTime {}s".format(
            self.epoch_num, self.epoch_size, self.metric_name, val_metric, val_time), flush = True)
