# Copyright 2021 Pengcheng Laboratory
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

import mindspore.nn as nn
from mindspore.common import dtype as mstype
from mindspore.common.parameter import Parameter
from mindspore.common.tensor import Tensor
from mindspore.communication.management import get_group_size
from mindspore.nn.metrics import Metric
from mindspore.nn.metrics import get_metric_fn
from mindspore.nn.wrap.grad_reducer import DistributedGradReducer
from mindspore.ops import functional as F
from mindspore.ops import operations as P
from mindspore.train import Model
from mindspore.train.callback import CheckpointConfig, ModelCheckpoint, LossMonitor, TimeMonitor
from mindspore.train.serialization import load_checkpoint, load_param_into_net

from suwen.algorithm.utils import clip_grad, grad_scale
from suwen.engine import callback

GRADIENT_CLIP_TYPE = 1
GRADIENT_CLIP_VALUE = 1.0

class EngineTrainOneStepWithLossScaleCell(nn.TrainOneStepWithLossScaleCell):
    """
    Encapsulation class of bert network training.

    Append an optimizer to the training network after that the construct
    function can be called to create the backward graph.

    Args:
        network (Cell): The training network. Note that loss function should have been added.
        optimizer (Optimizer): Optimizer for updating the weights.
        scale_update_cell (Cell): Cell to do the loss scale. Default: None.
    """

    def __init__(self, network, optimizer, scale_update_cell=None, clip_grad=True):
        super(EngineTrainOneStepWithLossScaleCell, self).__init__(network, optimizer, scale_update_cell)
        self.cast = P.Cast()
        self.degree = 1
        self.clip_grad = clip_grad
        if self.reducer_flag:
            self.degree = get_group_size()
            self.grad_reducer = DistributedGradReducer(optimizer.parameters, False, self.degree)

        self.loss_scale = None
        self.loss_scaling_manager = scale_update_cell
        if scale_update_cell:
            self.loss_scale = Parameter(Tensor(scale_update_cell.get_loss_scale(), dtype = mstype.float32))

    def construct(self, *inputs):
        """Defines the computation performed."""
        weights = self.weights
        loss = self.network(*inputs)
        scaling_sens = self.loss_scale
        status, scaling_sens = self.start_overflow_check(loss, scaling_sens)
        grads = self.grad(self.network, weights)(*inputs, self.cast(scaling_sens, mstype.float32))

        grads = self.grad_reducer(grads)
        grads = self.hyper_map(F.partial(grad_scale, scaling_sens * self.degree), grads)
        if self.clip_grad:
            grads = self.hyper_map(F.partial(clip_grad, GRADIENT_CLIP_TYPE, GRADIENT_CLIP_VALUE), grads)

        cond = self.get_overflow_status(status, grads)
        overflow = self.loss_scaling_manager(self.loss_scale, cond)
        if overflow:
            succ = False
        else:
            succ = self.optimizer(grads)
        ret = (loss, cond, scaling_sens)
        return F.depend(ret, succ)

class Engine:
    def __init__(self, network, eval_network=None, loss_fn=None, optimizer=None, metrics=None, amp_level="O0",
                 loss_scale_manager=None, fp32_bn=True, multiple_input=False, clip_grad=True):
        self.network = network
        self.eval_network = eval_network
        self.loss_fn = loss_fn
        self.opt = optimizer
        self.metrics = metrics
        self.metric_keys = []
        self.metric_count = 0
        self.amp_level = amp_level
        self.fp32_bn = fp32_bn
        self.scale_manager = loss_scale_manager
        self.multiple_input = multiple_input
        self.clip_grad = clip_grad
        self.callbacks = [callback.FormatPrint()]
        self._check_metrics()

    def _check_metrics(self):
        if self.metrics:
            if isinstance(self.metrics, Metric) or isinstance(self.metrics, str):
                self.metric_keys.append("user_metric_%d" % self.metric_count)
                self.metric_count += 1
                self.metrics = {self.metric_keys[0]: self.metrics}
            elif isinstance(self.metrics, list) or isinstance(self.metrics, set):
                new_metric = dict()
                for metric in self.metrics:
                    if isinstance(metric, Metric):
                        metric_name = "user_metric_%d" % self.metric_count
                        new_metric[metric_name] = metric
                        self.metric_keys.append(metric_name)
                    elif isinstance(metric, str):
                        new_metric[metric] = get_metric_fn(metric)
                        self.metric_keys.append(metric)
                    else:
                        raise KeyError("Non-metric object found, fail to initialize metric functions.")
                    self.metric_count += 1
                self.metrics = new_metric
            elif isinstance(self.metrics, dict):
                self.metric_keys = list(self.metrics.keys())
                self.metric_count = len(self.metric_keys)

    def _build_model(self):
        return Model(network = self.network,
                     loss_fn = self.loss_fn,
                     optimizer = self.opt,
                     metrics = self.metrics,
                     eval_network = self.eval_network,
                     amp_level = self.amp_level,
                     loss_scale_manager = self.scale_manager,
                     keep_batchnorm_fp32 = self.fp32_bn)

    def _run(self, epoch=1, train_dataset=None, eval_dataset=None, dataset_sink_mode=True, sink_size=100,
             loss_monitor=True, time_monitor=True, save_checkpoints=None, load_ckpt_path=""):
        if load_ckpt_path:
            param_dict = load_checkpoint(load_ckpt_path)
            load_param_into_net(self.network, param_dict)
        if self.multiple_input:
            if self.metrics:
                raise KeyError("multiple input do not support adding metrics, if you want to "
                               "eval with self-define metric, please add a callback")
            if self.loss_fn:
                self.network = nn.WithLossCell(self.network, self.loss_fn)
            self.network = EngineTrainOneStepWithLossScaleCell(self.network, self.opt,
                                                               self.scale_manager, clip_grad)
            self.loss_fn = None
            self.opt = None
            self.scale_manager = None
        else:
            if self.network is None or self.loss_fn is None or self.opt is None:
                raise KeyError("For a two-input network, please set network, loss function and optimizer")

        self.model = self._build_model()
        if loss_monitor:
            self.callbacks.append(LossMonitor(sink_size))
        if time_monitor:
            self.callbacks.append(TimeMonitor(sink_size))

        if eval_dataset:
            for index in range(self.metric_count):
                self.callbacks.append(callback.MetricCallback(self.model, eval_dataset,
                                                              list(self.metric_keys)[index], epoch = epoch))
        for call in self.callbacks:
            if isinstance(call, callback.MetricCallback):
                call = call.update_model(self.model)
        if save_checkpoints is not None:
            if not isinstance(save_checkpoints, dict):
                raise KeyError("save_checkpoint only supports with dict.")
            default_config = {'max_num': 5,
                              'save_step': 1,
                              'prefix': 'ckpt_',
                              'root': './'}
            for key in save_checkpoints.keys():
                if key not in ['max_num', 'save_step', 'prefix', 'root']:
                    raise KeyError("save checkpoint config should in ['max_num', 'save_step','prefix','root']")
                default_config[key] = save_checkpoints[key]

            checkpoint_config = CheckpointConfig(save_checkpoint_steps = default_config['save_step'],
                                                 keep_checkpoint_max = default_config['max_num'])
            checkpoint_cb = ModelCheckpoint(prefix = default_config['prefix'],
                                            directory = default_config['root'],
                                            config = checkpoint_config)
            self.callbacks.append(checkpoint_cb)

        self.model.train(epoch = epoch,
                         train_dataset = train_dataset,
                         callbacks = self.callbacks,
                         dataset_sink_mode = dataset_sink_mode,
                         sink_size = sink_size)

    def add_callback(self, callbacks):
        if isinstance(callbacks, list):
            for call in callbacks:
                if call in self.callbacks:
                    continue
                self.callbacks.append(call)
        elif isinstance(callbacks, object):
            if callbacks not in self.callbacks:
                self.callbacks.append(callbacks)
        elif isinstance(callbacks, dict):
            for call in callbacks.values():
                if call in self.callbacks:
                    continue
                self.callbacks.append(call)
        else:
            raise KeyError("Unknown callback type found.")

    def train_and_eval(self, epoch, train_dataset, eval_dataset, dataset_sink_mode=True, sink_size=100,
                       loss_monitor=True, time_monitor=True, save_checkpoints=None, load_ckpt_path=""):
        self._run(epoch = epoch,
                  train_dataset = train_dataset,
                  eval_dataset = eval_dataset,
                  dataset_sink_mode = dataset_sink_mode,
                  sink_size = sink_size,
                  loss_monitor = loss_monitor,
                  time_monitor = time_monitor,
                  save_checkpoints = save_checkpoints,
                  load_ckpt_path = load_ckpt_path)

    def eval(self, valid_dataset, dataset_sink_mode=True, load_ckpt_path="./"):
        self.model = self._build_model()
        param_dict = load_checkpoint(load_ckpt_path)
        load_param_into_net(self.network, param_dict)
        res = []
        for index in range(self.metric_count):
            res.append(self.model.eval(valid_dataset, dataset_sink_mode=dataset_sink_mode)[list(self.metric_keys)[index]])
        print('eval result: ', res)
        return res

    def train(self, epoch, train_dataset, dataset_sink_mode=True, sink_size=100,
              loss_monitor=True, time_monitor=True, save_checkpoints=None, load_ckpt_path=""):
        self._run(epoch,
                  train_dataset,
                  dataset_sink_mode = dataset_sink_mode,
                  sink_size = sink_size,
                  loss_monitor = loss_monitor,
                  time_monitor = time_monitor,
                  save_checkpoints = save_checkpoints,
                  load_ckpt_path = load_ckpt_path)
